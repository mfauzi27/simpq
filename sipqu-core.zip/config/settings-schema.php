<?php
/**
 * Config Settings Schema
 *
 * Mendefinisikan struktur data untuk kolom JSON 'settings' di tabel tenants.
 * Digunakan untuk validasi dan pembuatan form pengaturan secara dinamis.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

/**
 * Mengembalikan schema pengaturan sistem.
 *
 * @return array
 */
function sipqu_get_settings_schema() {

    $schema = array(

        // ============================================================
        // 1. GENERAL SETTINGS (Umum)
        // ============================================================
        'app_name' => array(
            'label'       => 'Nama Aplikasi',
            'type'        => 'text',
            'description' => 'Nama yang tampil di header aplikasi.',
            'default'     => 'SIPQU',
            'sanitize'    => 'text_field'
        ),
        
        'academic_year_start' => array(
            'label'       => 'Tahun Ajaran Mulai (Bulan)',
            'type'        => 'number',
            'description' => 'Bulan awal tahun ajaran (misal: 7 untuk Juli).',
            'default'     => 7,
            'sanitize'    => 'intval'
        ),

        'timezone' => array(
            'label'       => 'Zona Waktu',
            'type'        => 'select',
            'options'     => array( // List pilihan manual
                'Asia/Jakarta' => 'WIB (Asia/Jakarta)',
                'Asia/Makassar' => 'WITA (Asia/Makassar)',
                'Asia/Jayapura' => 'WIT (Asia/Jayapura)',
            ),
            'default'     => 'Asia/Jakarta',
            'sanitize'    => 'sanitize_text_field'
        ),

        // ============================================================
        // 2. INVOICE / FINANCE SETTINGS
        // ============================================================
        'invoice_prefix' => array(
            'label'       => 'Prefix No. Invoice',
            'type'        => 'text',
            'description' => 'Awalan nomor tagihan (Misal: INV-).',
            'default'     => 'INV/',
            'sanitize'    => 'sanitize_title' // Bersihkan karakter aneh
        ),

        'invoice_start_number' => array(
            'label'       => 'Mulai Nomor Invoice',
            'type'        => 'number',
            'description' => 'Digit awal nomor invoice.',
            'default'     => 1001,
            'sanitize'    => 'intval'
        ),

        // ============================================================
        // 3. WHATSAPP GATEWAY (NOTIFIKASI)
        // ============================================================
        'wa_gateway' => array(
            // Nested Group
            'type'        => 'group', // Penanda khusus jika ingin membuat section di UI
            'fields'      => array(
                'enabled' => array(
                    'label'    => 'Aktifkan Notifikasi WA',
                    'type'     => 'boolean', // Checkbox
                    'default'  => false,
                    'sanitize' => 'rest_sanitize_boolean'
                ),
                'provider' => array(
                    'label'    => 'Provider',
                    'type'     => 'select',
                    'options'  => array(
                        'wablas' => 'Wablas',
                        'squad'  => 'Squad',
                        'fonnte' => 'Fonnte',
                    ),
                    'default'  => 'wablas',
                    'sanitize' => 'sanitize_text_field'
                ),
                'api_key'  => array(
                    'label'    => 'API Key',
                    'type'     => 'password', // Input password
                    'default'  => '',
                    'sanitize' => 'sanitize_text_field'
                ),
                'sender_id' => array(
                    'label'    => 'Sender ID',
                    'type'     => 'text',
                    'description' => 'Nomor Pengirim atau ID Device.',
                    'default'  => '0',
                    'sanitize' => 'sanitize_text_field'
                ),
            )
        ),

        // ============================================================
        // 4. PAYMENT GATEWAY (QRIS/VA)
        // ============================================================
        'payment_gateway' => array(
            'type'   => 'group',
            'fields' => array(
                'midtrans_server_key' => array(
                    'label'    => 'Midtrans Server Key',
                    'type'     => 'password',
                    'default'  => '',
                    'sanitize' => 'sanitize_text_field'
                ),
                'is_production' => array(
                    'label'    => 'Mode Production (Sandbox?)',
                    'type'     => 'boolean',
                    'description' => 'Ceklis jika server sudah live. Kosongkan untuk Sandbox.',
                    'default'  => false,
                    'sanitize' => 'rest_sanitize_boolean'
                ),
            )
        ),

        // ============================================================
        // 5. ASSETS
        // ============================================================
        'branding' => array(
            'type'   => 'group',
            'fields' => array(
                'logo_url' => array(
                    'label'    => 'URL Logo Lembaga',
                    'type'     => 'url',
                    'default'  => '',
                    'sanitize' => 'esc_url_raw'
                ),
                'header_color' => array(
                    'label'    => 'Warna Header',
                    'type'     => 'text', // Hex Color
                    'default'  => '#1e8cbe',
                    'sanitize' => 'sanitize_hex_color'
                ),
            )
        ),

    );

    /**
     * Filter: Memungkinkan plugin tambahan menambahkan field setting
     */
    return apply_filters( 'sipqu_settings_schema', $schema );
}