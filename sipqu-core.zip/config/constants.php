<?php
/**
 * Config Constants
 *
 * Mendefinisikan konstanta konfigurasi global untuk perilaku sistem SIPQU.
 * Konstanta ini menggunakan pola `if (!defined())` agar dapat di-override
 * lewat `wp-config.php` jika diperlukan untuk instalasi khusus.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

// ============================================================
// 1. API CONFIGURATION
// ============================================================

if ( ! defined( 'SIPQU_API_NAMESPACE' ) ) {
    // Namespace REST API default: /wp-json/sipqu/v1/...
    define( 'SIPQU_API_NAMESPACE', 'sipqu/v1' );
}

if ( ! defined( 'SIPQU_API_RATE_LIMIT' ) ) {
    // Batas request per menit per user untuk API
    define( 'SIPQU_API_RATE_LIMIT', 60 );
}

// ============================================================
// 2. PAGINATION LIMITS
// ============================================================

if ( ! defined( 'SIPQU_ITEMS_PER_PAGE' ) ) {
    // Jumlah item per halaman (Admin List, API Response)
    define( 'SIPQU_ITEMS_PER_PAGE', 20 );
}

if ( ! defined( 'SIPQU_EXPORT_LIMIT' ) ) {
    // Batas baris maksimal untuk export Excel (Mencegah timeout pada Shared Hosting)
    define( 'SIPQU_EXPORT_LIMIT', 5000 );
}

// ============================================================
// 3. FINANCIAL DEFAULTS
// ============================================================

if ( ! defined( 'SIPQU_DEFAULT_CURRENCY' ) ) {
    define( 'SIPQU_DEFAULT_CURRENCY', 'IDR' );
}

if ( ! defined( 'SIPQU_DEFAULT_CURRENCY_SYMBOL' ) ) {
    define( 'SIPQU_DEFAULT_CURRENCY_SYMBOL', 'Rp' );
}

if ( ! defined( 'SIPQU_THOUSAND_SEPARATOR' ) ) {
    // Pemisah ribuan (Indonesia: Titik)
    define( 'SIPQU_THOUSAND_SEPARATOR', '.' );
}

if ( ! defined( 'SIPQU_DECIMAL_SEPARATOR' ) ) {
    // Pemisah desimal (Indonesia: Koma)
    define( 'SIPQU_DECIMAL_SEPARATOR', ',' );
}

// ============================================================
// 4. DATE & TIME FORMATS
// ============================================================

if ( ! defined( 'SIPQU_DATE_FORMAT' ) ) {
    // Format tampilan tanggal (d/m/Y = 31/12/2023)
    define( 'SIPQU_DATE_FORMAT', 'd/m/Y' );
}

if ( ! defined( 'SIPQU_DATETIME_FORMAT' ) ) {
    // Format tampilan tanggal lengkap dengan waktu
    define( 'SIPQU_DATETIME_FORMAT', 'd/m/Y H:i' );
}

if ( ! defined( 'SIPQU_DB_DATE_FORMAT' ) ) {
    // Format tanggal MySQL (Y-m-d = 2023-12-31)
    define( 'SIPQU_DB_DATE_FORMAT', 'Y-m-d' );
}

// ============================================================
// 5. ROLE SLUGS (Consistency Keys)
// ============================================================

if ( ! defined( 'SIPQU_ROLE_SUPER_ADMIN' ) ) {
    define( 'SIPQU_ROLE_SUPER_ADMIN', 'sipqu_super_admin' );
}
if ( ! defined( 'SIPQU_ROLE_ADMIN' ) ) {
    define( 'SIPQU_ROLE_ADMIN', 'sipqu_admin' );
}
if ( ! defined( 'SIPQU_ROLE_BENDAHARA' ) ) {
    define( 'SIPQU_ROLE_BENDAHARA', 'sipqu_bendahara' );
}
if ( ! defined( 'SIPQU_ROLE_PENGURUS' ) ) {
    define( 'SIPQU_ROLE_PENGURUS', 'sipqu_pengurus' );
}
if ( ! defined( 'SIPQU_ROLE_ASATIDZ' ) ) {
    define( 'SIPQU_ROLE_ASATIDZ', 'sipqu_asatidz' );
}
if ( ! defined( 'SIPQU_ROLE_WALI' ) ) {
    define( 'SIPQU_ROLE_WALI', 'sipqu_wali' );
}

// ============================================================
// 6. SYSTEM BEHAVIORS
// ============================================================

if ( ! defined( 'SIPQU_ENABLE_DEBUG_MODE' ) ) {
    // Mode debug (True akan menampilkan error detail di response API)
    define( 'SIPQU_ENABLE_DEBUG_MODE', false );
}

if ( ! defined( 'SIPQU_TAX_ENABLED' ) ) {
    // Fitur Pajak (PPN) apakah aktif?
    define( 'SIPQU_TAX_ENABLED', false );
}
/**
 * Config Constants
 *
 * Mendefinisikan konstanta konfigurasi global untuk perilaku sistem SIPQU.
 * Konstanta ini menggunakan pola `if (!defined())` agar dapat di-override
 * lewat `wp-config.php` jika diperlukan untuk instalasi khusus.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

// ============================================================
// 1. API CONFIGURATION
// ============================================================

if ( ! defined( 'SIPQU_API_NAMESPACE' ) ) {
    define( 'SIPQU_API_NAMESPACE', 'sipqu/v1' );
}

if ( ! defined( 'SIPQU_API_RATE_LIMIT' ) ) {
    define( 'SIPQU_API_RATE_LIMIT', 60 );
}

// ============================================================
// 2. PAGINATION
// ============================================================

if ( ! defined( 'SIPQU_ITEMS_PER_PAGE' ) ) {
    define( 'SIPQU_ITEMS_PER_PAGE', 20 );
}

if ( ! defined( 'SIPQU_EXPORT_LIMIT' ) ) {
    define( 'SIPQU_EXPORT_LIMIT', 5000 );
}

// ============================================================
// 3. FINANCIAL DEFAULTS
// ============================================================

if ( ! defined( 'SIPQU_DEFAULT_CURRENCY' ) ) {
    define( 'SIPQU_DEFAULT_CURRENCY', 'IDR' );
}

if ( ! defined( 'SIPQU_DEFAULT_CURRENCY_SYMBOL' ) ) {
    define( 'SIPQU_DEFAULT_CURRENCY_SYMBOL', 'Rp' );
}

if ( ! defined( 'SIPQU_THOUSAND_SEPARATOR' ) ) {
    define( 'SIPQU_THOUSAND_SEPARATOR', '.' );
}

if ( ! defined( 'SIPQU_DECIMAL_SEPARATOR' ) ) {
    define( 'SIPQU_DECIMAL_SEPARATOR', ',' );
}

// ============================================================
// 4. DATE & TIME FORMATS
// ============================================================

if ( ! defined( 'SIPQU_DATE_FORMAT' ) ) {
    define( 'SIPQU_DATE_FORMAT', 'd/m/Y' );
}

if ( ! defined( 'SIPQU_DATETIME_FORMAT' ) ) {
    define( 'SIPQU_DATETIME_FORMAT', 'd/m/Y H:i' );
}

if ( ! defined( 'SIPQU_DB_DATE_FORMAT' ) ) {
    define( 'SIPQU_DB_DATE_FORMAT', 'Y-m-d' );
}

// ============================================================
// 5. ROLE SLUGS
// ============================================================

if ( ! defined( 'SIPQU_ROLE_SUPER_ADMIN' ) ) {
    define( 'SIPQU_ROLE_SUPER_ADMIN', 'sipqu_super_admin' );
}
if ( ! defined( 'SIPQU_ROLE_ADMIN' ) ) {
    define( 'SIPQU_ROLE_ADMIN', 'sipqu_admin' );
}
if ( ! defined( 'SIPQU_ROLE_BENDAHARA' ) ) {
    define( 'SIPQU_ROLE_BENDAHARA', 'sipqu_bendahara' );
}
if ( ! defined( 'SIPQU_ROLE_PENGURUS' ) ) {
    define( 'SIPQU_ROLE_PENGURUS', 'sipqu_pengurus' );
}
if ( ! defined( 'SIPQU_ROLE_ASATIDZ' ) ) {
    define( 'SIPQU_ROLE_ASATIDZ', 'sipqu_asatidz' );
}
if ( ! defined( 'SIPQU_ROLE_WALI' ) ) {
    define( 'SIPQU_ROLE_WALI', 'sipqu_wali' );
}

// ============================================================
// 6. SYSTEM BEHAVIORS
// ============================================================

if ( ! defined( 'SIPQU_ENABLE_DEBUG_MODE' ) ) {
    define( 'SIPQU_ENABLE_DEBUG_MODE', false );
}

if ( ! defined( 'SIPQU_TAX_ENABLED' ) ) {
    define( 'SIPQU_TAX_ENABLED', false );
}