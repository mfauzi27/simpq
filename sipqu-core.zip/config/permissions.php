<?php
/**
 * Config Permissions
 *
 * Mendefinisikan daftar lengkap Capability (Izin) untuk setiap Role.
 * File ini dibuat agar struktur hak akses mudah dimodifikasi.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

/**
 * Mengambil peta permission (Role vs Capabilities).
 * Dapat di-filter menggunakan hook 'sipqu_permissions_map'.
 *
 * @return array
 */
function sipqu_get_permission_map() {

    // Peta dasar permission
    $permissions = array(

        // ============================================================
        // 1. SIPQU SUPER ADMIN (Owner / Pengurus Yayasan)
        // ============================================================
        'sipqu_super_admin' => array(
            // Wildcard: Memiliki akses ke SEMUA hal
            '*' 
        ),

        // ============================================================
        // 2. ADMIN LPQ (Kepala Sekolah)
        // ============================================================
        'sipqu_admin' => array(
            'dashboard.view',
            
            // Student Module
            'student.view', 'student.create', 'student.update', 'student.delete',
            
            // SWS Module (Full Access)
            'sws.view', 'sws.create', 'sws.edit', 'sws.delete', 'sws.settings', 'sws.pay',
            
            // Finance Module (Can Approve)
            'finance.view', 'finance.create', 'finance.update', 'finance.approve', 'finance.delete',
            
            // Reports
            'report.view', 'report.export', 'report.manage',
            
            // Settings
            'system.settings', 'system.manage_users', 'audit.view'
        ),

        // ============================================================
        // 3. BENDAHARA (Keuangan)
        // ============================================================
        'sipqu_bendahara' => array(
            'dashboard.view',
            
            // Student (View only for reference)
            'student.view',
            
            // SWS (Can manage invoices & payments, but not delete settings)
            'sws.view', 'sws.create', 'sws.edit', 'sws.pay', 
            // 'sws.delete' -> Di-comment karena bendahara sebaiknya tidak hapus data keuangan
            // 'sws.settings' -> Di-comment karena setting nominal biasanya keputusan admin
            
            // Finance (Can create journals, NOT delete/approve large sums alone)
            'finance.view', 'finance.create', 'finance.update',
            
            // Reports
            'report.view', 'report.export',
        ),

        // ============================================================
        // 4. PENGURUS / OPERASIONAL
        // ============================================================
        'sipqu_pengurus' => array(
            'dashboard.view',
            
            // Student (Manage data santri)
            'student.view', 'student.create', 'student.update',
            
            // Asset (Manage inventaris)
            'asset.view', 'asset.create', 'asset.update',
            
            // HR (Manage data guru, tapi tidak gaji)
            'hr.view', 'hr.create', 'hr.update',
            
            // Donation
            'donation.view', 'donation.manage',
            
            'report.view',
        ),

        // ============================================================
        // 5. ASATIDZ (Guru)
        // ============================================================
        'sipqu_asatidz' => array(
            'dashboard.view',
            'student.view',
            'attendance.view', 'attendance.input',
            'honor.view', // Melihat gaji sendiri
            'academic.view'
        ),

        // ============================================================
        // 6. WALI SANTRI (Parent)
        // ============================================================
        'sipqu_wali' => array(
            'student.view',    // Hanya lihat anaknya (logic filter di controller)
            'sws.view',         // Lihat tagihan anak
            'attendance.view',  // Lihat kehadiran anak
            'report.view'
        ),
    );

    // Filter untuk mengizinkan Plugin Tambahan mengubah permission
    // Contoh: Plugin Tambahan menambah izin 'sws.print' untuk bendahara
    return apply_filters( 'sipqu_permissions_map', $permissions );
}