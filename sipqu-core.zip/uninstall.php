<?php
/**
 * Uninstall
 *
 * Menjalankan script penghapusan database saat plugin dihapus (Uninstall).
 * PERINGATAN: Ini akan menghapus SEMUA DATA SIPQU.
 *
 * @package SIPQU_CORE
 */

// Cek jika ini adalah request uninstall yang valid (bukan direct access)
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Load WordPress
require_once dirname( __FILE__ ) . '/../../wp-load.php';

global $wpdb;
 $prefix = $wpdb->prefix . 'sipqu_';

// Opsi: Hapus Tabel
// Uncomment baris di bawah jika ingin membersihkan database total saat uninstall.

/*
 $tables = array(
    'audit_logs',
    'user_tenants',
    'branches',
    'tenants'
);

foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS {$prefix}{$table}" );
}
*/

// Opsi: Hapus Options (Settings)
$wpdb->query( "DELETE FROM {$wpdb->prefix}options WHERE option_name IN ('sipqu_db_version', 'sipqu_activated')" );