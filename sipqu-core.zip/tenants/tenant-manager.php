<?php
/**
 * Tenant Manager (Model)
 *
 * Menangani logika database untuk Tenant. Pemisahan logika dari View (Admin UI).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Tenant_Manager {

    /**
     * Ambil Data Tenant berdasarkan ID
     */
    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . SIPQU_DB::table('tenants') . " WHERE id = %d",
            $id
        ) );
    }

    /**
     * Update Data Tenant
     */
    public static function update( $id, $data ) {
        // Sanitasi dasar di sini
        if ( isset( $data['tenant_name'] ) ) $data['tenant_name'] = sanitize_text_field( $data['tenant_name'] );
        if ( isset( $data['address'] ) )      $data['address'] = sanitize_textarea_field( $data['address'] );
        if ( isset( $data['phone'] ) )        $data['phone'] = sanitize_text_field( $data['phone'] );

        $data['updated_at'] = current_time( 'mysql' );

        return SIPQU_DB::update( 'tenants', $data, array( 'id' => $id ) );
    }

    /**
     * Cek apakah kode tenant unik (kecuali untuk dirinya sendiri)
     */
    public static function is_code_unique( $code, $exclude_id = 0 ) {
        global $wpdb;
        $table = SIPQU_DB::table('tenants');
        
        $sql = "SELECT id FROM {$table} WHERE tenant_code = %s";
        if ( $exclude_id > 0 ) {
            $sql .= " AND id != %d";
            $exists = $wpdb->get_var( $wpdb->prepare( $sql, $code, $exclude_id ) );
        } else {
            $exists = $wpdb->get_var( $wpdb->prepare( $sql, $code ) );
        }

        return empty( $exists );
    }
}