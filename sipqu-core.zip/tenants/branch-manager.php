<?php
/**
 * Branch Manager (Model)
 *
 * Menangani logika database untuk Cabang (Branches).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Branch_Manager {

    /**
     * Ambil semua cabang milik tenant tertentu
     */
    public static function get_all_by_tenant( $tenant_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . SIPQU_DB::table('branches') . 
            " WHERE tenant_id = %d ORDER BY is_main DESC, id ASC",
            $tenant_id
        ) );
    }

    /**
     * Tambah cabang baru
     */
    public static function create( $data ) {
        $sanitized_data = array(
            'branch_name' => sanitize_text_field( $data['branch_name'] ),
            'address'     => sanitize_textarea_field( $data['address'] ),
            'phone'       => sanitize_text_field( $data['phone'] ),
            'is_main'     => isset( $data['is_main'] ) ? 1 : 0
        );

        // tenant_id di-inject otomatis oleh SIPQU_DB::insert
        return SIPQU_DB::insert( 'branches', $sanitized_data );
    }

    /**
     * Hapus cabang (Soft delete logic bisa ditambahkan disini)
     */
    public static function delete( $id ) {
        return SIPQU_DB::delete( 'branches', $id );
    }
}