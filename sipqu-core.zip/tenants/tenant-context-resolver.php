<?php
/**
 * Tenant Context Resolver
 *
 * Logic kompleks untuk menentukan Tenant ID user berdasarkan berbagai sumber:
 * - User Meta (Preferensi Tersimpan)
 * - Database Mapping (Tabel user_tenants)
 * - API Headers (untuk Integrasi Sistem Lain)
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Tenant_Context_Resolver {

    /**
     * Mendapatkan Context Tenant berdasarkan Preferensi User Meta (Session)
     * Dipanggil saat user login via Browser (Admin UI).
     *
     * @param int $user_id
     * @return array|null ['tenant_id', 'branch_id', 'role'] atau NULL
     */
    public static function resolve_from_preference( $user_id ) {
        
        // 1. Cek preferensi tersimpan di User Meta
        $saved_tenant_id = get_user_meta( $user_id, 'sipqu_active_tenant_id', true );
        $saved_branch_id = get_user_meta( $user_id, 'sipqu_active_branch_id', true );

        // 2. Validasi apakah user masih memiliki akses ke tenant tersebut
        // (Mungkin user baru saja dihapus dari tenant oleh Admin, tapi meta masih lama)
        if ( $saved_tenant_id ) {
            $role = self::get_user_role( $user_id, $saved_tenant_id, $saved_branch_id );
            
            if ( $role ) {
                return array(
                    'tenant_id' => (int) $saved_tenant_id,
                    'branch_id' => (int) ($saved_branch_id ?: 0),
                    'role'      => $role
                );
            }
        }

        // 3. Jika preferensi kosong/invalid, cari Tenant pertama yang user punya akses
        // Ini kasus pertama kali login
        $first_access = self::get_first_available_tenant( $user_id );

        if ( $first_access ) {
            // Simpan sebagai default otomatis
            update_user_meta( $user_id, 'sipqu_active_tenant_id', $first_access['tenant_id'] );
            update_user_meta( $user_id, 'sipqu_active_branch_id', $first_access['branch_id'] );
            
            return $first_access;
        }

        // 4. Tidak ada akses tenant manapun
        return null;
    }

    /**
     * Mendapatkan Tenant ID dari Request API (Stateless)
     * Sistem SIPQU mengizinkan API Override Tenant via Header untuk sistem integrasi (misal Billing System).
     *
     * @param WP_REST_Request $request
     * @return int|null
     */
    public static function resolve_from_api( $request ) {
        
        // 1. Cek Override Header (Hanya untuk Super Admin/System integration)
        // Jika header 'X-SIPQU-Tenant-Id' ada, kita paksa pakai ID itu.
        $override_tenant = $request->get_header( 'X-SIPQU-Tenant-Id' );

        if ( $override_tenant ) {
            $user_id = get_current_user_id();
            
            // Validasi: Pastikan user memang punya akses ke tenant override
            if ( self::has_access_to_tenant( $user_id, $override_tenant ) ) {
                return (int) $override_tenant;
            }
        }

        // 2. Fallback: Gunakan logic resolusi biasa (Preference -> Database)
        // Karena API sessionless, kita ambil dari data user saat ini
        return self::resolve_from_preference( get_current_user_id() )['tenant_id'] ?? null;
    }

    /**
     * Helper: Mengambil role user di tenant tertentu
     *
     * @param int    $user_id
     * @param int    $tenant_id
     * @param int    $branch_id Opsional (untuk mempersempit pencarian)
     * @return string|false
     */
    private static function get_user_role( $user_id, $tenant_id, $branch_id = 0 ) {
        global $wpdb;
        
        $where = array( $user_id, $tenant_id );
        $sql_where = "user_id = %d AND tenant_id = %d AND status = 'active'";
        
        // Jika branch id spesifik, kita pakai itu
        if ( $branch_id ) {
            $sql_where .= " AND branch_id = %d";
            $where[] = $branch_id;
        }

        $role = $wpdb->get_var( $wpdb->prepare(
            "SELECT role FROM " . SIPQU_DB::table('user_tenants') . " 
             WHERE {$sql_where} 
             LIMIT 1",
            $where
        ) );

        return $role ?: false;
    }

    /**
     * Helper: Mengambil akses tenant pertama yang tersedia
     *
     * @param int $user_id
     * @return array|null
     */
    private static function get_first_available_tenant( $user_id ) {
        global $wpdb;
        
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT tenant_id, branch_id, role 
             FROM " . SIPQU_DB::table('user_tenants') . " 
             WHERE user_id = %d AND status = 'active' 
             ORDER BY created_at ASC 
             LIMIT 1",
            $user_id
        ), ARRAY_A );
    }

    /**
     * Helper: Cek apakah user punya akses ke tenant manapun
     *
     * @param int    $user_id
     * @param string $tenant_id
     * @return bool
     */
    private static function has_access_to_tenant( $user_id, $tenant_id ) {
        global $wpdb;
        
        $count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . SIPQU_DB::table('user_tenants') . " 
             WHERE user_id = %d AND tenant_id = %d AND status = 'active'",
            $user_id,
            $tenant_id
        ) );

        return $count > 0;
    }

    /**
     * Helper: Mendapatkan SEMUA daftar tenant yang bisa diakses user
     * Berguna untuk UI "Switch Tenant" dropdown
     *
     * @param int $user_id
     * @return array
     */
    public static function get_available_tenants( $user_id ) {
        global $wpdb;
        
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT ut.tenant_id, t.tenant_name, ut.branch_id, b.branch_name, ut.role
             FROM " . SIPQU_DB::table('user_tenants') . " ut
             JOIN " . SIPQU_DB::table('tenants') . " t ON ut.tenant_id = t.id
             LEFT JOIN " . SIPQU_DB::table('branches') . " b ON ut.branch_id = b.id
             WHERE ut.user_id = %d AND ut.status = 'active' 
             ORDER BY t.tenant_name ASC",
            $user_id
        ) );
    }
}