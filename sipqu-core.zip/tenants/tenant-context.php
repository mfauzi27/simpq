<?php
/**
 * Tenant Context Resolver
 *
 * Menangani logika Multi-Tenant: Menentukan tenant_id, branch_id, dan role
 * untuk user yang sedang login dan menyimpannya di scope global.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Tenant_Context {

    /**
     * Key untuk menyimpan context di Global Variable
     */
    const GLOBAL_KEY = 'sipqu_context';

    /**
     * Resolve Tenant Context
     * Dipanggil saat hook 'init'.
     * 
     * Logic:
     * 1. Cek apakah user sudah login.
     * 2. Cek database mapping (wp_sipqu_user_tenants).
     * 3. Jika user punya banyak Tenant, cek preferensi tersimpan di User Meta.
     * 4. Simpan ke $GLOBALS agar bisa diakses di seluruh request.
     *
     * @return void
     */
    public static function resolve() {
        // 1. Jika belum login, return (bypass)
        if ( ! is_user_logged_in() ) {
            return;
        }

        // 2. Jika context sudah di-set manual (misal oleh API Switch), jangan override
        if ( isset( $GLOBALS[ self::GLOBAL_KEY ] ) ) {
            return;
        }

        $user_id = get_current_user_id();
        
        // 3. Query mapping user ke tenant
        global $wpdb;
        $table_name = SIPQU_DB::table('user_tenants');

        // Cek preferensi aktif yang tersimpan di User Meta (untuk handle multi-tenant)
        $active_tenant_id = get_user_meta( $user_id, 'sipqu_active_tenant_id', true );
        $active_branch_id = get_user_meta( $user_id, 'sipqu_active_branch_id', true );

        // Persiapan query
        $where = ["user_id = %d", "status = 'active'"];
        $prepare_args = [ $user_id ];

        // Jika user punya preferensi tenant aktif, filter berdasarkan itu
        if ( $active_tenant_id ) {
            $where[] = "tenant_id = %d";
            $prepare_args[] = intval( $active_tenant_id );
            
            if ( $active_branch_id ) {
                $where[] = "branch_id = %d";
                $prepare_args[] = intval( $active_branch_id );
            }
        }

        // Limit 1 untuk performa (ambil konteks aktif)
        $where_clause = implode( ' AND ', $where );
        
        $row = $wpdb->get_row( 
            $wpdb->prepare(
                "SELECT tenant_id, branch_id, role FROM {$table_name} WHERE {$where_clause} ORDER BY created_at ASC LIMIT 1",
                $prepare_args
            ) 
        );

        // 4. Jika data tidak ditemukan (User belum dipetakan ke Tenant manapun)
        if ( ! $row ) {
            // Opsional: Redirect ke halaman "Akses Ditolak" atau hanya biarkan kosong
            // Di sini kita tidak melakukan wp_die agar admin WP utama (Super Admin) 
            // yang belum masuk SIPQU tidak terkunci.
            return;
        }

        // 5. Simpan ke Context Global
        self::set_context( [
            'tenant_id' => (int) $row->tenant_id,
            'branch_id' => (int) $row->branch_id,
            'role'      => sanitize_text_field( $row->role ),
        ] );

        // Opsional: Simpan ke User Meta jika belum ada (auto-set pertama kali)
        if ( ! $active_tenant_id ) {
            update_user_meta( $user_id, 'sipqu_active_tenant_id', $row->tenant_id );
            update_user_meta( $user_id, 'sipqu_active_branch_id', $row->branch_id );
        }
    }

    /**
     * Set Context Manual (Override)
     * Digunakan saat user memilih tenant dari dropdown switcher.
     *
     * @param array $data ['tenant_id' => int, 'branch_id' => int, 'role' => string]
     */
    public static function set( $data ) {
        self::set_context( $data );
        
        // Simpan preferensi ke database agar persistensi
        if ( is_user_logged_in() ) {
            update_user_meta( get_current_user_id(), 'sipqu_active_tenant_id', $data['tenant_id'] );
            update_user_meta( get_current_user_id(), 'sipqu_active_branch_id', $data['branch_id'] );
        }
    }

    /**
     * Internal helper untuk menyimpan ke $GLOBALS
     */
    private static function set_context( $data ) {
        $GLOBALS[ self::GLOBAL_KEY ] = [
            'tenant_id' => isset( $data['tenant_id'] ) ? (int) $data['tenant_id'] : 0,
            'branch_id' => isset( $data['branch_id'] ) ? (int) $data['branch_id'] : 0,
            'role'      => isset( $data['role'] ) ? sanitize_text_field( $data['role'] ) : 'guest',
        ];
    }

    // ============================================================
    // GETTERS (Dipanggil oleh Modul lain)
    // ============================================================

    /**
     * Ambil Tenant ID saat ini
     */
    public static function tenant_id() {
        return $GLOBALS[ self::GLOBAL_KEY ]['tenant_id'] ?? 0;
    }

    /**
     * Ambil Branch ID saat ini
     */
    public static function branch_id() {
        return $GLOBALS[ self::GLOBAL_KEY ]['branch_id'] ?? 0;
    }

    /**
     * Ambil Role SIPQU saat ini
     */
    public static function role() {
        return $GLOBALS[ self::GLOBAL_KEY ]['role'] ?? 'guest';
    }

    /**
     * Cek apakah user memiliki role tertentu
     */
    public static function has_role( $roles ) {
        $current_role = self::role();
        if ( is_array( $roles ) ) {
            return in_array( $current_role, $roles );
        }
        return $current_role === $roles;
    }

    /**
     * Mendapatkan full array context
     */
    public static function get() {
        return $GLOBALS[ self::GLOBAL_KEY ] ?? [];
    }

    /**
     * Flush context (Logout)
     */
    public static function flush() {
        if ( isset( $GLOBALS[ self::GLOBAL_KEY ] ) ) {
            unset( $GLOBALS[ self::GLOBAL_KEY ] );
        }
    }
}