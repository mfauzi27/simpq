<?php
/**
 * Upgrader - Database Migration Logic
 *
 * Menangani pembaruan struktur database saat versi plugin naik (upgrade).
 * Menggunakan dbDelta untuk perubahan yang aman (tidak merusak data).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Upgrader {

    /**
     * Cek kebutuhan upgrade dan jalankan jika diperlukan.
     * Dipanggil via loader.php di hook 'plugins_loaded'.
     *
     * @return void
     */
    public static function check() {
        $current_db_version = get_option( 'sipqu_db_version' );
        $target_version = SIPQU_DB_VERSION;

        // Jika versi sama, tidak perlu upgrade.
        if ( version_compare( $current_db_version, $target_version, '>=' ) ) {
            return;
        }

        // Jalankan proses upgrade
        self::run_upgrade( $current_db_version );

        // Update versi database di options
        update_option( 'sipqu_db_version', $target_version );
    }

    /**
     * Jalankan logika upgrade langkah demi langkah.
     * Logika ini memastikan upgrade dapat dilompati (misal dari 1.0.0 langsung ke 1.2.0).
     *
     * @param string $from_version Versi database saat ini.
     * @return void
     */
    private static function run_upgrade( $from_version ) {
        global $wpdb;
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

        // Contoh: Upgrade dari versi di bawah 1.1.0
        if ( version_compare( $from_version, '1.1.0', '<' ) ) {
            self::upgrade_to_1_1_0();
        }

        // Contoh: Upgrade dari versi di bawah 1.2.0
        if ( version_compare( $from_version, '1.2.0', '<' ) ) {
            self::upgrade_to_1_2_0();
        }

        // Flush rewrite rules di akhir upgrade
        flush_rewrite_rules();
    }

    // ============================================================
    // FUNGSI UPGRADE KHUSUS PER VERSI
    // ============================================================

    /**
     * Upgrade ke versi 1.1.0
     * Perubahan: Menambah kolom 'deleted_at' untuk fitur Soft Delete di tabel core.
     */
    private static function upgrade_to_1_1_0() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix . 'sipqu_';

        // Tambahkan kolom deleted_at ke tabel audit_logs
        // dbDelta cukup pintar untuk menambahkan kolom jika belum ada.
        $sql = "CREATE TABLE {$prefix}audit_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            deleted_at DATETIME NULL
        ) $charset;";

        dbDelta( $sql );
    }

    /**
     * Upgrade ke versi 1.2.0
     * Perubahan: Menambah kolom JSON settings di tabel tenants
     * untuk menyimpan konfigurasi fleksibel.
     */
    private static function upgrade_to_1_2_0() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix . 'sipqu_';

        $sql = "CREATE TABLE {$prefix}tenants (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            settings JSON NULL
        ) $charset;";

        dbDelta( $sql );
    }

    /**
     * Upgrade ke versi 1.3.0 (Contoh Lain)
     * Perubahan: Menambah index untuk performa query di tabel user_tenants.
     */
    private static function upgrade_to_1_3_0() {
        global $wpdb;
        $prefix = $wpdb->prefix . 'sipqu_';

        // Menambahkan index secara manual jika belum ada
        // Cek dulu apakah index sudah ada untuk mencegah error duplicate key
        $table_name = $prefix . 'user_tenants';
        $index_name = 'idx_role_status';
        
        $row = $wpdb->get_row("SHOW INDEX FROM $table_name WHERE Key_name = '$index_name'");
        
        if ( ! $row ) {
            $wpdb->query("ALTER TABLE {$table_name} ADD INDEX {$index_name} (role, status)");
        }
    }
}