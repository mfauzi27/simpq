<?php
/**
 * Activator - Plugin Activation Logic
 *
 * Menangani logika saat plugin diaktifkan: Install DB, Setup Roles, dan Cron Jobs.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Core_Activator {

    /**
     * Method utama yang dipanggil saat aktivasi.
     *
     * @return void
     */
    public static function activate() {
        // 1. Install Database Tabel Core
        if ( class_exists( 'SIPQU_Installer' ) ) {
            SIPQU_Installer::install();
        }

        // 2. Setup Default Roles & Capabilities
        require_once SIPQU_CORE_PATH . 'auth/roles.php';
        SIPQU_Roles::init();

        // 3. Setup Cron Jobs (Scheduled Tasks)
        self::setup_cron_jobs();

        // 4. Flush Rewrite Rules (Penting untuk REST API)
        flush_rewrite_rules();

        // 5. Set Flag Initial Activation (Opsional, untuk Redirect ke Setup Wizard)
        if ( ! get_option( 'sipqu_activated' ) ) {
            update_option( 'sipqu_activated', time() );
        }
    }

    /**
     * Membuat Role khusus SIPQU jika belum ada.
     * Role ini ditambahkan ke sistem WordPress agar bisa dipilih di User Management.
     */
    private static function create_roles() {
        
        // 1. Role: SIPQU Super Admin (Pemilik Yayasan)
        // Memiliki akses penuh ke semua tenant (menggunakan logic manual mapping).
        if ( ! get_role( 'sipqu_super_admin' ) ) {
            add_role( 'sipqu_super_admin', __( 'SIPQU Super Admin', 'sipqu-core' ), array(
                'read' => true,
                'manage_sipqu' => true, // Cap kustom utama
            ) );
        }

        // 2. Role: Admin LPQ
        // Pengurus inti LPQ, akses full tapi hanya di tenant-nya sendiri.
        if ( ! get_role( 'sipqu_admin' ) ) {
            add_role( 'sipqu_admin', __( 'Admin LPQ', 'sipqu-core' ), array(
                'read' => true,
                'manage_sipqu' => true,
            ) );
        }

        // 3. Role: Bendahara (Keuangan)
        // Akses khusus modul SWS dan Finance.
        if ( ! get_role( 'sipqu_bendahara' ) ) {
            add_role( 'sipqu_bendahara', __( 'Bendahara LPQ', 'sipqu-core' ), array(
                'read' => true,
                'sws.view' => true,
                'sws.edit' => true,
                'sws.delete' => true,
                'finance.view' => true,
                'finance.create' => true,
                'reports.view' => true,
            ) );
        }

        // 4. Role: Asatidz (Guru)
        // Akses absensi dan jadwal mengajar.
        if ( ! get_role( 'sipqu_asatidz' ) ) {
            add_role( 'sipqu_asatidz', __( 'Asatidz / Guru', 'sipqu-core' ), array(
                'read' => true,
                'student.view' => true,
                'attendance.view' => true,
            ) );
        }

        // 5. Role: Wali Santri (Read Only)
        // Akses khusus via Frontend atau Parent Portal.
        if ( ! get_role( 'sipqu_wali' ) ) {
            add_role( 'sipqu_wali', __( 'Wali Santri', 'sipqu-core' ), array(
                'read' => true,
            ) );
        }

        // Tambahkan Capabilities ke Administrator WordPress Utama
        // Agar Admin WP bisa masuk SIPQU tanpa perlu diassign role khusus.
        $admin_role = get_role( 'administrator' );
        if ( $admin_role && ! $admin_role->has_cap( 'manage_sipqu' ) ) {
            $admin_role->add_cap( 'manage_sipqu' );
        }
    }

    /**
     * Menjadwalkan tugas otomatis (Cron).
     * Contoh: Pembersihan cache harian, reminder jatuh tempo (di-handle oleh modul).
     */
    private static function setup_cron_jobs() {
        
        // Cron Harian: General Maintenance (Misal: Audit Log Cleanup jika setting memungkinkan)
        if ( ! wp_next_scheduled( 'sipqu_daily_maintenance' ) ) {
            wp_schedule_event( time(), 'daily', 'sipqu_daily_maintenance' );
        }

        // Cron per 15 menit: High Priority Tasks (Queue worker emulation via Action Scheduler)
        // Catatan: Untuk shared hosting, Action Scheduler lebih direkomendasikan daripada wp_cron.
        // Di sini kita buat hook dasar.
        if ( ! wp_next_scheduled( 'sipqu_hourly_sync' ) ) {
            wp_schedule_event( time(), 'hourly', 'sipqu_hourly_sync' );
        }
    }
}