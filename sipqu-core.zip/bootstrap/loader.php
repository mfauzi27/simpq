<?php
/**
 * Loader - Bootstrap SIPQU Core
 *
 * File ini memuat semua dependensi, class inti, dan menginisialisasi hooks.
 * Menjaga file sipqu-core.php tetap bersih.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

/**
 * Fungsi utama untuk memuat semua file inti SIPQU.
 */
function sipqu_load_core() {

    // -----------------------------------------------------------
    // 1. LIFECYCLE & DATABASE (Paling awal)
    // -----------------------------------------------------------
    // Memuat logika install, uninstall, dan upgrade database
    require_once SIPQU_CORE_PATH . 'bootstrap/activator.php';
    require_once SIPQU_CORE_PATH . 'bootstrap/deactivator.php';
    require_once SIPQU_CORE_PATH . 'bootstrap/installer.php';
    require_once SIPQU_CORE_PATH . 'bootstrap/upgrader.php';

    // -----------------------------------------------------------
    // 2. CONFIGURATION
    // -----------------------------------------------------------
    // Memuat konstanta tambahan (jika ada) dan skema permissions
    require_once SIPQU_CORE_PATH . 'config/constants.php';
    require_once SIPQU_CORE_PATH . 'config/permissions.php';
    require_once SIPQU_CORE_PATH . 'config/settings-schema.php';

    // -----------------------------------------------------------
    // 3. HELPER CLASSES (Utilities Global)
    // -----------------------------------------------------------
    // Helper ini dipakai oleh hampir semua modul lain
    require_once SIPQU_CORE_PATH . 'helpers/db.php';
    require_once SIPQU_CORE_PATH . 'helpers/response.php';
    require_once SIPQU_CORE_PATH . 'helpers/validator.php';
    require_once SIPQU_CORE_PATH . 'helpers/formatter.php';

    // -----------------------------------------------------------
    // 4. CORE CLASSES (Sistem Inti)
    // -----------------------------------------------------------
    // Tenant Context wajib dipertama karena modul lain butuh tenant_id
    require_once SIPQU_CORE_PATH . 'tenants/tenant-context.php';
    require_once SIPQU_CORE_PATH . 'tenants/tenant-manager.php';
    require_once SIPQU_CORE_PATH . 'tenants/branch-manager.php';

    // Auth & Security
    require_once SIPQU_CORE_PATH . 'auth/capability-checker.php';
    require_once SIPQU_CORE_PATH . 'auth/access-middleware.php';
    
    // Audit Log
    require_once SIPQU_CORE_PATH . 'audit/audit-logger.php';

    // Security Layer
    require_once SIPQU_CORE_PATH . 'security/nonce-validator.php';
    require_once SIPQU_CORE_PATH . 'security/rate-limit.php';

    // -----------------------------------------------------------
    // 5. API CONTROLLERS
    // -----------------------------------------------------------
    require_once SIPQU_CORE_PATH . 'api/rest-init.php';
    require_once SIPQU_CORE_PATH . 'api/auth-controller.php';
    require_once SIPQU_CORE_PATH . 'api/system-controller.php';

    // -----------------------------------------------------------
    // 6. ADMIN PAGES (Backend UI)
    // -----------------------------------------------------------
    // Jika user sedang di admin panel
    if ( is_admin() ) {
        require_once SIPQU_CORE_PATH . 'admin/setup-page.php';
        require_once SIPQU_CORE_PATH . 'admin/settings-page.php';
        require_once SIPQU_CORE_PATH . 'audit/audit-viewer.php';
    }
}

// Jalankan fungsi loader
sipqu_load_core();

// ============================================================
// HOOKS & EVENT LISTENERS
// ============================================================

/**
 * Hook: plugins_loaded (Priority 5)
 * Digunakan untuk mengecek apakah database perlu di-upgrade
 * sebelum sistem berjalan sepenuhnya.
 */
add_action('plugins_loaded', 'sipqu_check_database_upgrade', 5);

/**
 * Hook: init (Priority 10)
 * Menginisialisasi konteks Tenant dan load text domain.
 */
add_action('init', 'sipqu_initialize_system', 10);

/**
 * Hook: rest_api_init (Priority 10)
 * Mendaftarkan route REST API internal.
 */
add_action('rest_api_init', 'sipqu_register_api_routes', 10);

/**
 * Hook: admin_enqueue_scripts
 * Memuat CSS dan JS admin SIPQU.
 */
add_action('admin_enqueue_scripts', 'sipqu_load_admin_assets');

// ============================================================
// CALLBACK FUNCTIONS
// ============================================================

/**
 * Cek versi database dan jalankan upgrade jika diperlukan.
 */
function sipqu_check_database_upgrade() {
    // Fungsi ini ada di file upgrader.php
    if ( class_exists( 'SIPQU_Upgrader' ) && method_exists( 'SIPQU_Upgrader', 'check' ) ) {
        SIPQU_Upgrader::check();
    }
}

/**
 * Inisialisasi Sistem (Tenant Resolution & Localization).
 */
function sipqu_initialize_system() {
    // 1. Load Text Domain (Terjemahan Bahasa)
    load_plugin_textdomain('sipqu-core', false, dirname(SIPQU_CORE_BASENAME) . '/languages');

    // 2. Resolve Tenant Context
    // Ini langkah KRITIS. Menentukan tenant_id user yang sedang login.
    if ( is_user_logged_in() ) {
        // Panggil method resolve dari class Tenant_Context
        if ( class_exists( 'SIPQU_Tenant_Context' ) ) {
            SIPQU_Tenant_Context::resolve();
        }
    }
}

/**
 * Registrasi Route API.
 */
function sipqu_register_api_routes() {
    if ( class_exists( 'SIPQU_REST_Init' ) ) {
        SIPQU_REST_Init::register_routes();
    }
}

/**
 * Load CSS & JS untuk Halaman Admin.
 */
function sipqu_load_admin_assets($hook) {
    // Hanya load assets di halaman yang berhubungan dengan SIPQU
    // Prefix halaman SIPQU biasanya 'sipqu_' atau 'toplevel_page_sipqu'
    if ( strpos($hook, 'sipqu') === false ) {
        return;
    }

    // Load CSS Global
    wp_enqueue_style(
        'sipqu-admin-global', 
        SIPQU_CORE_URL . 'assets/css/admin-global.css', 
        array(), 
        SIPQU_CORE_VERSION
    );

    // Load JS Global (berisi helper Select2, Datepicker, dll)
    wp_enqueue_script(
        'sipqu-admin-global', 
        SIPQU_CORE_URL . 'assets/js/admin-global.js', 
        array('jquery'), 
        SIPQU_CORE_VERSION, 
        true
    );

    // Localize Script (Mengirim data PHP ke JS)
    wp_localize_script('sipqu-admin-global', 'sipquData', array(
        'apiUrl' => rest_url('sipqu/v1/'),
        'nonce'  => wp_create_nonce('wp_rest'),
        'tenant' => array(
            'id' => SIPQU_Tenant_Context::tenant_id(),
            'branch' => SIPQU_Tenant_Context::branch_id()
        )
    ));
}