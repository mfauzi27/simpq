<?php
/**
 * Deactivator - Plugin Deactivation Logic
 *
 * Menangani logika saat plugin dinonaktifkan: Pembersihan Cron Jobs dan Flush Rules.
 * CATATAN: Tidak ada data yang dihapus saat deactivation demi keamanan data.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Core_Deactivator {

    /**
     * Method utama yang dipanggil saat deaktivasi.
     *
     * @return void
     */
    public static function deactivate() {
        // 1. Hapus semua penjadwalan Cron (Scheduled Events)
        self::clear_cron_jobs();

        // 2. Flush Rewrite Rules
        // Membersihkan endpoint API atau permalink kustom agar tidak konflik.
        flush_rewrite_rules();

        // 3. Opsional: Bersihkan Transients / Cache Sementara
        self::clear_cache();

        // 4. Log Audit (Opsional)
        // Catat bahwa sistem telah dinonaktifkan oleh user tertentu.
        if ( class_exists( 'SIPQU_Audit_Logger' ) && method_exists( 'SIPQU_Audit_Logger', 'log' ) ) {
            // Catat log hanya jika Audit Logger sudah terload sebelum hook deactivation
            SIPQU_Audit_Logger::log( 'system', 'deactivate', null, null, ['user_id' => get_current_user_id()] );
        }
    }

    /**
     * Menghapus semua scheduled events milik SIPQU.
     * Mencegah server tetap bekerja memproses job saat plugin mati.
     */
    private static function clear_cron_jobs() {
        
        // Hapus cron maintenance harian
        wp_clear_scheduled_hook( 'sipqu_daily_maintenance' );

        // Hapus cron sync per jam
        wp_clear_scheduled_hook( 'sipqu_hourly_sync' );
        
        // Catatan: Cron yang terdaftar oleh modul lain (SWS, Finance)
        // sebaiknya juga memiliki hook deactivation sendiri di file modul tersebut.
    }

    /**
     * Membersihkan data sementara (Transients) yang mungkin disimpan plugin.
     */
    private static function clear_cache() {
        // Contoh: Menghapus cache dashboard widget
        delete_transient( 'sipqu_dashboard_stats' );
        
        // Hapus option flag "activated" jika ada (agar setup wizard bisa muncul lagi jika diaktifkan ulang)
        delete_option( 'sipqu_activated' );
    }
}