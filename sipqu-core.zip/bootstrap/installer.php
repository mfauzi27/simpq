<?php
/**
 * Installer - Database Creation
 *
 * Menangani pembuatan tabel database utama SIPQU (Core Tables) 
 * menggunakan dbDelta() untuk keamanan dan kompatibilitas update.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Installer {

    /**
     * Method utama untuk menjalankan instalasi.
     * Dipanggil dari activator.php.
     *
     * @return void
     */
    public static function install() {
        global $wpdb;
        
        // 1. Load upgrade.php agar fungsi dbDelta tersedia
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // 2. Ambil charset database
        $charset = $wpdb->get_charset_collate();
        
        // 3. Definisikan Prefix Tabel SIPQU
        $prefix = $wpdb->prefix . 'sipqu_';

        // ============================================================
        // SCHEMA TABLE CORE
        // ============================================================

        // 1. Tabel Tenants (Data LPQ/Lembaga)
        $sql_tenants = "CREATE TABLE {$prefix}tenants (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            tenant_code VARCHAR(50) UNIQUE NOT NULL,
            tenant_name VARCHAR(255) NOT NULL,
            status ENUM('active','inactive','suspended') DEFAULT 'active',
            subscription_plan VARCHAR(50) DEFAULT 'free',
            settings LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY `status` (`status`)
        ) $charset;";

        // 2. Tabel Branches (Cabang LPQ)
        $sql_branches = "CREATE TABLE {$prefix}branches (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            tenant_id BIGINT UNSIGNED NOT NULL,
            branch_name VARCHAR(255) NOT NULL,
            address TEXT,
            phone VARCHAR(30),
            is_main TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            KEY `tenant_id` (`tenant_id`)
        ) $charset;";

        // 3. Tabel User Tenants (Mapping WP User ke SIPQU Tenant & Role)
        // Ini adalah tabel penghubung antara sistem login WP dan SIPQU
        $sql_user_tenants = "CREATE TABLE {$prefix}user_tenants (
            user_id BIGINT UNSIGNED NOT NULL,
            tenant_id BIGINT UNSIGNED NOT NULL,
            branch_id BIGINT UNSIGNED NULL,
            role VARCHAR(50) NOT NULL,
            status ENUM('active','inactive') DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (user_id, tenant_id),
            KEY `role` (`role`),
            KEY `status` (`status`),
            KEY `tenant_id` (`tenant_id`)
        ) $charset;";

        // 4. Tabel Audit Logs (Log Aktivitas Sistem)
        // Wajib ada untuk akuntabilitas
        $sql_audit_logs = "CREATE TABLE {$prefix}audit_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            tenant_id BIGINT UNSIGNED NULL,
            user_id BIGINT UNSIGNED NULL,
            module VARCHAR(100) NOT NULL,
            action VARCHAR(50) NOT NULL,
            object_id BIGINT UNSIGNED NULL,
            old_data LONGTEXT NULL,
            new_data LONGTEXT NULL,
            ip_address VARCHAR(45),
            user_agent VARCHAR(255),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            KEY `tenant_id` (`tenant_id`),
            KEY `module` (`module`),
            KEY `created_at` (`created_at`)
        ) $charset;";

        // ============================================================
        // EKSEKUSI CREATE TABLE
        // ============================================================
        
        dbDelta( $sql_tenants );
        dbDelta( $sql_branches );
        dbDelta( $sql_user_tenants );
        dbDelta( $sql_audit_logs );

        // ============================================================
        // SEED DATA AWAL (Opsional)
        // ============================================================
        // Kita bisa masukkan config default di sini jika perlu.
        // Namun untuk modular system, sebaiknya data sebarang (COA, etc) 
        // dikelola oleh modul masing-masing.

        // 4. Update Versi Database di Options Table
        // Ini menandakan bahwa instalasi DB core sukses
        if ( function_exists( 'update_option' ) ) {
            update_option( 'sipqu_db_version', SIPQU_DB_VERSION );
        }
    }
}