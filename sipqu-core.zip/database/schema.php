<?php
/**
 * Database Schema Definition
 *
 * Mendefinisikan struktur tabel core dalam format Array PHP.
 * Digunakan sebagai referensi, dokumentasi, atau untuk unit testing.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Database_Schema {

    /**
     * Mengembalikan struktur tabel Core (Tenants, Users, Audit).
     *
     * @return array Associative array dari definisi tabel.
     */
    public static function get_core_schema() {
        return array(

            // ============================================================
            // 1. TABEL TENANTS (Data LPQ)
            // ============================================================
            'tenants' => array(
                'primary_key' => 'id',
                'columns' => array(
                    'id'                 => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'auto_increment' => true),
                    'tenant_code'        => array('type' => 'VARCHAR', 'length' => 50,  'null' => false, 'unique' => true),
                    'tenant_name'        => array('type' => 'VARCHAR', 'length' => 255, 'null' => false),
                    'status'             => array('type' => 'VARCHAR', 'length' => 20,  'null' => false, 'default' => 'active'),
                    'subscription_plan'  => array('type' => 'VARCHAR', 'length' => 50,  'default' => 'free'),
                    'settings'           => array('type' => 'JSON',    'null' => true),
                    'created_at'         => array('type' => 'DATETIME', 'null' => false, 'default' => 'CURRENT_TIMESTAMP'),
                    'updated_at'         => array('type' => 'DATETIME', 'null' => false, 'extra' => 'ON UPDATE CURRENT_TIMESTAMP'),
                ),
                'indexes' => array(
                    'idx_status' => array('column' => 'status')
                )
            ),

            // ============================================================
            // 2. TABEL BRANCHES (Cabang LPQ)
            // ============================================================
            'branches' => array(
                'primary_key' => 'id',
                'columns' => array(
                    'id'             => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'auto_increment' => true),
                    'tenant_id'      => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => false),
                    'branch_name'    => array('type' => 'VARCHAR', 'length' => 255, 'null' => false),
                    'address'        => array('type' => 'TEXT',    'null' => true),
                    'phone'          => array('type' => 'VARCHAR', 'length' => 30,  'null' => true),
                    'is_main'        => array('type' => 'TINYINT', 'length' => 1,  'default' => 0),
                    'created_at'     => array('type' => 'DATETIME', 'null' => false, 'default' => 'CURRENT_TIMESTAMP'),
                ),
                'foreign_keys' => array(
                    'fk_tenant' => array('column' => 'tenant_id', 'ref_table' => 'tenants', 'ref_column' => 'id', 'on_delete' => 'CASCADE')
                ),
                'indexes' => array(
                    'idx_tenant_id' => array('column' => 'tenant_id')
                )
            ),

            // ============================================================
            // 3. TABEL USER TENANTS (Mapping WP User ke SIPQU Tenant)
            // ============================================================
            'user_tenants' => array(
                'primary_key' => array('user_id', 'tenant_id'), // Composite Key
                'columns' => array(
                    'user_id'        => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => false),
                    'tenant_id'      => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => false),
                    'branch_id'      => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => true),
                    'role'           => array('type' => 'VARCHAR', 'length' => 50,  'null' => false),
                    'status'         => array('type' => 'VARCHAR', 'length' => 20,  'null' => false, 'default' => 'active'),
                    'created_at'     => array('type' => 'DATETIME', 'null' => false, 'default' => 'CURRENT_TIMESTAMP'),
                ),
                'foreign_keys' => array(
                    'fk_tenant' => array('column' => 'tenant_id', 'ref_table' => 'tenants', 'ref_column' => 'id', 'on_delete' => 'CASCADE'),
                    'fk_branch' => array('column' => 'branch_id', 'ref_table' => 'branches', 'ref_column' => 'id', 'on_delete' => 'SET NULL')
                ),
                'indexes' => array(
                    'idx_role'   => array('column' => 'role'),
                    'idx_status' => array('column' => 'status')
                )
            ),

            // ============================================================
            // 4. TABEL AUDIT LOGS (Log Aktivitas Sistem)
            // ============================================================
            'audit_logs' => array(
                'primary_key' => 'id',
                'columns' => array(
                    'id'             => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'auto_increment' => true),
                    'tenant_id'      => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => true), // NULL untuk System events
                    'user_id'        => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => true),
                    'module'         => array('type' => 'VARCHAR', 'length' => 100, 'null' => false),
                    'action'         => array('type' => 'VARCHAR', 'length' => 50,  'null' => false),
                    'object_id'      => array('type' => 'BIGINT', 'length' => 20, 'unsigned' => true, 'null' => true),
                    'old_data'       => array('type' => 'JSON',    'null' => true),
                    'new_data'       => array('type' => 'JSON',    'null' => true),
                    'ip_address'     => array('type' => 'VARCHAR', 'length' => 45,  'null' => true),
                    'user_agent'     => array('type' => 'VARCHAR', 'length' => 255, 'null' => true),
                    'created_at'     => array('type' => 'DATETIME', 'null' => false, 'default' => 'CURRENT_TIMESTAMP'),
                ),
                'indexes' => array(
                    'idx_tenant' => array('column' => 'tenant_id'),
                    'idx_module'  => array('column' => 'module'),
                    'idx_date'    => array('column' => 'created_at')
                )
            ),

        );
    }
}