<?php
/**
 * Seed Default Chart of Accounts (COA)
 *
 * Memasukkan akun-akun standar untuk Sistem Keuangan (Double Entry).
 * Dipanggil saat LPQ (Tenant) pertama kali dibuat.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Seed_Default_COA {

    /**
     * Menjalankan penanaman data untuk Tenant tertentu.
     * Cek duplikasi terlebih dahulu agar tidak error.
     *
     * @param int $tenant_id
     * @return void
     */
    public static function run( $tenant_id ) {
        global $wpdb;
        $table_name = SIPQU_DB::table( 'accounts' );

        // 1. Cek apakah akun default (101 - Kas Tunai) sudah ada
        // Jika sudah ada, asumsikan seeding sudah dilakukan sebelumnya
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE tenant_id = %d AND code = '101'",
            $tenant_id
        ) );

        if ( $existing ) {
            return;
        }

        // 2. Definisi Akun Standar (Struktur Akun Indonesia)
        $accounts = array(
            // ASET (ACTIVA)
            array( 'code' => '101', 'name' => 'Kas Tunai',          'type' => 'asset',   'description' => 'Uang di tangan' ),
            array( 'code' => '102', 'name' => 'Kas Bank',           'type' => 'asset',   'description' => 'Uang di rekening bank' ),
            array( 'code' => '103', 'name' => 'Kas Kecil',          'type' => 'asset',   'description' => 'Uang belanja kebutuhan rutin' ),
            array( 'code' => '110', 'name' => 'Piutang SWS',        'type' => 'asset',   'description' => 'Uang tagihan santri (Sumbangan)' ),
            
            // KEWAJIBAN (PASIVA)
            array( 'code' => '201', 'name' => 'Hutang Usaha',       'type' => 'liability', 'description' => 'Hutang dagang' ),
            array( 'code' => '210', 'name' => 'Dana Amanah',         'type' => 'liability', 'description' => 'Dana tertentu (misal Zakat)' ),
            
            // EKUITAS (MODAL)
            array( 'code' => '301', 'name' => 'Modal Awal',         'type' => 'equity',   'description' => 'Modal awal pendirian LPQ' ),
            array( 'code' => '302', 'name' => 'Dana Lembaga',        'type' => 'equity',   'description' => 'Dana pengembangan' ),
            
            // PENDAPATAN
            array( 'code' => '401', 'name' => 'Pendapatan SWS',     'type' => 'income',   'description' => 'Pemasukan dari sumbangan santri' ),
            array( 'code' => '402', 'name' => 'Pendapatan Donasi',   'type' => 'income',   'description' => 'Pemasukan dari donasi umum' ),
            array( 'code' => '403', 'name' => 'Pendapatan Program',  'type' => 'income',   'description' => 'Pemasukan dari kegiatan khusus' ),
            
            // BEBAN (EXPENSE)
            array( 'code' => '501', 'name' => 'Beban Gaji',          'type' => 'expense',  'description' => 'Penggajian karyawan tetap' ),
            array( 'code' => '502', 'name' => 'Beban Honorarium',    'type' => 'expense',  'description' => 'Honor asatidz/guru honorer' ),
            array( 'code' => '503', 'name' => 'Beban Operasional',  'type' => 'expense',  'description' => 'Listrik, Air, Sewa, dll' ),
            array( 'code' => '504', 'name' => 'Beban Pendidikan',   'type' => 'expense',  'description' => 'Beli buku, alat tulis, dll' ),
        );

        // 3. Loop Insert
        foreach ( $accounts as $acc ) {
            $wpdb->insert(
                $table_name,
                array(
                    'tenant_id'   => $tenant_id,
                    'code'        => $acc['code'],
                    'account_name'=> $acc['name'],
                    'type'        => $acc['type'],
                    'description' => $acc['description'],
                    'created_at'  => current_time( 'mysql' )
                )
            );
        }
    }
}