-- ============================================================
-- MIGRATION v1.1.0: ADD AUDIT ACTION INDEX
-- Sistem Integrasi Pendidikan Al - Quran
-- ============================================================
-- DESKRIPSI:
-- Menambahkan database index pada kolom 'action' di tabel audit_logs.
--
-- ALASAN:
-- Fitur Audit Viewer yang baru dibuat memiliki filter pencarian 
-- berdasarkan 'Aksi' (create, update, delete).
-- Tanpa index, query "SELECT ... WHERE action = 'delete'" akan menjadi 
-- lambat saat data audit mencapai ribuan baris (Full Table Scan).
-- ============================================================

ALTER TABLE `wp_sipqu_audit_logs`
ADD INDEX `idx_action` (`action`);