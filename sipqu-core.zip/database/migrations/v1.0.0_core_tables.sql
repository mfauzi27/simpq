-- ============================================================
-- SIPQU CORE DATABASE SCHEMA v1.0.0
-- Sistem Integrasi Pendidikan Al - Quran
-- ============================================================

-- Menggunakan Engine InnoDB untuk mendukung Foreign Key
-- Menggunakan Charset utf8mb4 untuk support Emoji

-- ============================================================
-- 1. TABEL TENANTS (Data Lembaga / LPQ)
-- ============================================================
CREATE TABLE IF NOT EXISTS `wp_sipqu_tenants` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `tenant_code` VARCHAR(50) NOT NULL,
    `tenant_name` VARCHAR(255) NOT NULL,
    `status` ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
    `subscription_plan` VARCHAR(50) NOT NULL DEFAULT 'free',
    `settings` JSON NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_tenant_code` (`tenant_code`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. TABEL BRANCHES (Data Cabang)
-- ============================================================
CREATE TABLE IF NOT EXISTS `wp_sipqu_branches` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `tenant_id` BIGINT UNSIGNED NOT NULL,
    `branch_name` VARCHAR(255) NOT NULL,
    `address` TEXT NULL,
    `phone` VARCHAR(30) NULL,
    `is_main` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (`id`),
    KEY `idx_tenant_id` (`tenant_id`),
    
    CONSTRAINT `fk_branch_tenant`
        FOREIGN KEY (`tenant_id`)
        REFERENCES `wp_sipqu_tenants` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. TABEL USER TENANTS (Mapping WP User ke Tenant)
-- ============================================================
CREATE TABLE IF NOT EXISTS `wp_sipqu_user_tenants` (
    `user_id` BIGINT UNSIGNED NOT NULL,
    `tenant_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` BIGINT UNSIGNED NULL,
    `role` VARCHAR(50) NOT NULL,
    `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (`user_id`, `tenant_id`),
    KEY `idx_role` (`role`),
    KEY `idx_status` (`status`),
    KEY `idx_branch` (`branch_id`),
    
    CONSTRAINT `fk_user_tenant`
        FOREIGN KEY (`tenant_id`)
        REFERENCES `wp_sipqu_tenants` (`id`)
        ON DELETE CASCADE,
        
    CONSTRAINT `fk_user_branch`
        FOREIGN KEY (`branch_id`)
        REFERENCES `wp_sipqu_branches` (`id`)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. TABEL AUDIT LOGS (Riwayat Aktivitas)
-- ============================================================
CREATE TABLE IF NOT EXISTS `wp_sipqu_audit_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `tenant_id` BIGINT UNSIGNED NULL,
    `user_id` BIGINT UNSIGNED NULL,
    `module` VARCHAR(100) NOT NULL,
    `action` VARCHAR(50) NOT NULL,
    `object_id` BIGINT UNSIGNED NULL,
    `old_data` JSON NULL,
    `new_data` JSON NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(255) NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (`id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_module` (`module`),
    KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;