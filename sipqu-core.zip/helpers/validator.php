<?php
/**
 * Validator Helper
 *
 * Memvalidasi input data user (Required, Email, Phone, Length, Numeric).
 * Menyediakan sistem Error Collector agar mudah menampilkan pesan error.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Validator {

    /**
     * Tempat menyimpan pesan error saat proses validasi.
     * Format: ['field_name' => 'Pesan Error']
     */
    public static $errors = array();

    /**
     * Reset Error Collection
     * Panggil method ini sebelum memulai validasi form baru.
     */
    public static function reset() {
        self::$errors = array();
    }

    /**
     * Cek apakah ada error
     */
    public static function has_errors() {
        return ! empty( self::$errors );
    }

    /**
     * Mengambil semua error
     */
    public static function get_errors() {
        return self::$errors;
    }

    // ============================================================
    // RULES (ATURAN VALIDASI)
    // ============================================================

    /**
     * Required Check
     * Cek apakah field tidak kosong.
     *
     * @param string $field   Nama field (untuk label error).
     * @param mixed  $value    Nilai input.
     * @param string $custom_msg (Opsional) Pesan error kustom.
     * @return bool True jika valid, False jika error.
     */
    public static function required( $field, $value, $custom_msg = '' ) {
        if ( empty( $value ) ) {
            $msg = $custom_msg ?: ucfirst( $field ) . ' wajib diisi.';
            self::$errors[ $field ] = $msg;
            return false;
        }
        return true;
    }

    /**
     * Email Check
     *
     * @param string $field Nama field.
     * @param string $value Nilai input.
     * @return bool
     */
    public static function email( $field, $value ) {
        if ( ! empty( $value ) && ! is_email( $value ) ) {
            self::$errors[ $field ] = ucfirst( $field ) . ' harus berupa alamat email yang valid.';
            return false;
        }
        return true;
    }

    /**
     * Numeric Check
     * Cek apakah nilai adalah angka (integer atau float).
     *
     * @param string $field
     * @param mixed  $value
     * @return bool
     */
    public static function numeric( $field, $value ) {
        if ( ! empty( $value ) && ! is_numeric( $value ) ) {
            self::$errors[ $field ] = ucfirst( $field ) . ' harus berupa angka.';
            return false;
        }
        return true;
    }

    /**
     * Minimum Length Check
     * Untuk password atau kode unik.
     *
     * @param string $field
     * @param mixed  $value
     * @param int    $min_length
     * @return bool
     */
    public static function min_length( $field, $value, $min_length = 0 ) {
        if ( ! empty( $value ) && strlen( $value ) < $min_length ) {
            self::$errors[ $field ] = ucfirst( $field ) . ' minimal harus ' . $min_length . ' karakter.';
            return false;
        }
        return true;
    }

    /**
     * Phone Number Check (Indonesia Context)
     * Menerima format: 08xx, 628xx, +628xx
     *
     * @param string $field
     * @param string $value
     * @return bool
     */
    public static function phone( $field, $value ) {
        if ( ! empty( $value ) ) {
            // Regex sederhana untuk nomor HP Indonesia (min 10 digit)
            // Menerima 0 atau 62 atau +62 di depan
            if ( ! preg_match( '/^(\+62|0|62)[0-9]{9,15}$/', $value ) ) {
                self::$errors[ $field ] = ucfirst( $field ) . ' format tidak valid (Gunakan 08xx atau 628xx).';
                return false;
            }
        }
        return true;
    }

    /**
     * Date Check
     * Cek format tanggal (Y-m-d atau d/m/Y).
     *
     * @param string $field
     * @param string $value
     * @return bool
     */
    public static function date( $field, $value ) {
        if ( ! empty( $value ) ) {
            // Coba parse format d/m/Y (Input user Indo)
            if ( strtotime( str_replace( '/', '-', $value ) ) === false ) {
                // Jika gagal, coba format standar
                if ( strtotime( $value ) === false ) {
                    self::$errors[ $field ] = ucfirst( $field ) . ' format tanggal salah (Contoh: 31/12/2023).';
                    return false;
                }
            }
        }
        return true;
    }

    // ============================================================
    // SANITIZERS (PEMBERSIH INPUT)
    // ============================================================

    /**
     * Sanitasi input berdasarkan tipe data.
     *
     * @param mixed  $value
     * @param string $type text, email, int, float, url, slug, textarea
     * @return mixed
     */
    public static function sanitize( $value, $type = 'text' ) {
        if ( is_array( $value ) ) {
            return array_map( function( $v ) use ( $type ) {
                return self::sanitize( $v, $type );
            }, $value );
        }

        switch ( $type ) {
            case 'email':
                return sanitize_email( $value );
            case 'url':
                return esc_url_raw( $value );
            case 'slug':
            case 'code':
                return sanitize_title( $value ); // Buat jadi lowercase dan url-friendly
            case 'int':
                return intval( $value );
            case 'float':
                return floatval( $value );
            case 'textarea':
                return sanitize_textarea_field( $value );
            case 'text':
            default:
                return sanitize_text_field( $value );
        }
    }

    /**
     * Sanitasi Massal Array (Misal: Sanitasi seluruh $_POST)
     * Menerima array schema yang memetakan field ke tipe.
     *
     * @param array $data   Input array (contoh: $_POST)
     * @param array $schema ['field_name' => 'type']
     * @return array Data yang sudah bersih.
     */
    public static function sanitize_batch( $data, $schema ) {
        $clean_data = array();

        foreach ( $schema as $field => $type ) {
            if ( isset( $data[ $field ] ) ) {
                $clean_data[ $field ] = self::sanitize( $data[ $field ], $type );
            }
        }

        return $clean_data;
    }
}