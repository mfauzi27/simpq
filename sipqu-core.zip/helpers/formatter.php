<?php
/**
 * Formatter Helper
 *
 * Utility untuk format tampilan (Uang, Tanggal).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Formatter {

    /**
     * Format angka ke mata uang Rupiah
     */
    public static function currency( $amount ) {
        return 'Rp ' . number_format( (float) $amount, 0, ',', '.' );
    }

    /**
     * Format angka mentah (tanpa Rp, 2 desimal)
     */
    public static function number( $amount, $decimal = 2 ) {
        return number_format( (float) $amount, $decimal, ',', '.' );
    }

    /**
     * Format tanggal MySQL ke format Indonesia
     */
    public static function date( $date_string, $format = 'd/m/Y' ) {
        if ( empty( $date_string ) || $date_string === '0000-00-00' ) return '-';
        return date_i18n( $format, strtotime( $date_string ) );
    }

    /**
     * Format tanggal lengkap dengan waktu
     */
    public static function datetime( $date_string ) {
        return self::date( $date_string, 'd/m/Y H:i' );
    }
}