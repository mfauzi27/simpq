<?php
/**
 * Response Helper
 *
 * Standardisasi format output JSON untuk REST API.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Response {

    /**
     * Response Sukses Standar
     */
    public static function success( $data = null, $message = 'Success', $code = 200 ) {
        $body = array(
            'status'  => 'success',
            'message' => $message,
            'data'    => $data,
            'meta'    => array(
                'timestamp' => current_time( 'mysql' ),
                'version'   => SIPQU_CORE_VERSION
            )
        );

        return new WP_REST_Response( $body, $code );
    }

    /**
     * Response Error Standar
     */
    public static function error( $message = 'Error', $code = 400, $additional_data = array() ) {
        $body = array(
            'status'  => 'error',
            'message' => $message,
            'data'    => $additional_data
        );

        return new WP_Error( 'sipqu_error', $message, array( 'status' => $code ) );
    }
}