<?php
/**
 * Database Helper Class (SIPQU_DB)
 *
 * Utility class untuk berinteraksi dengan database WordPress ($wpdb).
 * Fokus pada keamanan, konsistensi prefix tabel, dan isolasi multi-tenant.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_DB {

    /**
     * Mendapatkan nama tabel lengkap dengan prefix.
     * Contoh: SIPQU_DB::table('students') -> "wp_sipqu_students"
     *
     * @param string $name Nama tabel tanpa prefix (hanya akhiran).
     * @return string Nama tabel lengkap.
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'sipqu_' . $name;
    }

    /**
     * Mendapatkan klausa WHERE untuk tenant saat ini.
     * Sangat penting untuk mencegah data bocor antar tenant.
     *
     * @param string $alias Alias tabel jika menggunakan JOIN (misal: 't.tenant_id').
     * @return string String klausa SQL (misal: "AND tenant_id = 1").
     */
    public static function tenant_where( $alias = '' ) {
        $tenant_id = SIPQU_Tenant_Context::tenant_id();

        // Jika tenant_id 0 (user login tapi tidak punya akses LPQ),
        // kembalikan kondisi false (1=0) agar query tidak return data apapun.
        if ( empty( $tenant_id ) ) {
            return "1=0";
        }

        $column = ! empty( $alias ) ? trim( $alias ) . '.tenant_id' : 'tenant_id';

        return "AND {$column} = " . intval( $tenant_id );
    }

    /**
     * Helper INSERT dengan otomatis menyertakan tenant_id.
     * Memastikan data yang masuk selalu terikat pada tenant aktif.
     *
     * @param string $table Nama tabel (tanpa prefix).
     * @param array  $data  Data associative array (key => value).
     * @return int|false ID baris yang di-insert, atau false jika gagal.
     */
    public static function insert( $table, $data ) {
        global $wpdb;

        // Cek apakah tenant_id sudah diset manual dalam data
        $tenant_id = SIPQU_Tenant_Context::tenant_id();

        if ( $tenant_id && ! isset( $data['tenant_id'] ) ) {
            $data['tenant_id'] = $tenant_id;
        }

        // Gunakan method insert bawaan $wpdb (sudah aman dari SQL Injection)
        $wpdb->insert( self::table( $table ), $data );

        return $wpdb->insert_id;
    }

    /**
     * Helper UPDATE dengan proteksi tenant_id.
     * Memaksa WHERE clause mencakup tenant_id agar user tidak bisa edit data tenant lain.
     *
     * @param string $table Nama tabel.
     * @param array  $data  Data yang diupdate.
     * @param array  $where Klausa WHERE (wajib ada).
     * @return int|false Jumlah baris terupdate, atau false.
     */
    public static function update( $table, $data, $where ) {
        global $wpdb;

        // Wajib inject tenant_id ke WHERE clause untuk keamanan
        $tenant_id = SIPQU_Tenant_Context::tenant_id();

        if ( $tenant_id && ! isset( $where['tenant_id'] ) ) {
            $where['tenant_id'] = $tenant_id;
        }

        return $wpdb->update( self::table( $table ), $data, $where );
    }

    /**
     * Soft Delete: Hapus data logis (update deleted_at).
     * JANGAN gunakan hard delete (DELETE FROM) untuk data transaksi agar Audit Log tetap utuh.
     *
     * @param string $table Nama tabel.
     * @param int    $id    ID record yang akan dihapus.
     * @return bool
     */
    public static function soft_delete( $table, $id ) {
        $current_time = current_time( 'mysql' );
        
        return self::update( 
            $table, 
            [ 'deleted_at' => $current_time ], 
            [ 'id' => $id ] 
        );
    }

    /**
     * Hard Delete (Berbahaya) - Hanya untuk data sampah/testing.
     * Gunakan soft_delete untuk produksi.
     *
     * @param string $table
     * @param int    $id
     * @return int|false
     */
    public static function delete( $table, $id ) {
        global $wpdb;

        $tenant_id = SIPQU_Tenant_Context::tenant_id();
        
        // Proteksi tambahan: hanya hapus jika milik tenant sendiri
        return $wpdb->delete(
            self::table( $table ),
            [ 'id' => $id, 'tenant_id' => $tenant_id ]
        );
    }

    /**
     * Helper untuk mendapatkan tanggal sekarang dalam format SQL DATETIME.
     * Menggunakan current_time('mysql') dari WP (menghandle timezone setting).
     *
     * @return string
     */
    public static function now() {
        return current_time( 'mysql' );
    }

    /**
     * Cek apakah record milik tenant aktif.
     * Utility method untuk validasi.
     *
     * @param string $table Nama tabel.
     * @param int    $id    ID record.
     * @return bool
     */
    public static function is_mine( $table, $id ) {
        global $wpdb;
        $tenant_id = SIPQU_Tenant_Context::tenant_id();

        if ( ! $tenant_id ) return false;

        $result = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . self::table( $table ) . " WHERE id = %d AND tenant_id = %d LIMIT 1",
            $id,
            $tenant_id
        ) );

        return ! empty( $result );
    }
}