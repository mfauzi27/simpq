<?php
/**
 * IP Whitelist
 *
 * Membatasi akses admin Dashboard berdasarkan IP Address.
 * Fitur opsional: Jika daftar IP kosong, semua akses diperbolehkan (Safe Default).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_IP_Whitelist {

    /**
     * Hook untuk mengecek IP saat user masuk halaman Admin.
     * Dipanggil di loader.php.
     */
    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'enforce_admin_access' ), 1 );
        // Juga cek untuk REST API jika request mencoba akses admin endpoints
        add_filter( 'rest_authentication_errors', array( __CLASS__, 'enforce_api_access' ), 1 );
    }

    /**
     * Cek akses Dashboard Admin
     * Jika IP user tidak ada di whitelist, blokir seketika.
     */
    public static function enforce_admin_access() {
        
        // Cek opsi settings whitelist
        // Default empty string = Fitur tidak aktif (biarkan semua lewat)
        $whitelist_ips = get_option( 'sipqu_admin_ip_whitelist', '' );

        if ( empty( $whitelist_ips ) ) {
            return; // Fitur non-aktif
        }

        // Parse string (misal: "192.168.1.1, 127.0.0.1") menjadi Array
        $allowed_ips = array_map( 'trim', explode( ',', $whitelist_ips ) );

        $current_ip = self::get_client_ip();

        // Cek apakah IP saat ini ada di list
        if ( ! in_array( $current_ip, $allowed_ips ) ) {
            // LOGIKA BLOCK
            // Kita buat log dulu (jika memungkinkan) sebelum mati
            if ( function_exists( 'wp_get_current_user' ) && is_user_logged_in() ) {
                // Catat ke Audit Log
                if ( class_exists( 'SIPQU_Audit_Logger' ) ) {
                    SIPQU_Audit_Logger::log( 'security', 'ip_blocked', null, array('ip' => $current_ip), null );
                }
            }

            wp_die(
                '<h1>Akses Ditolak</h1><p>IP Address Anda (' . esc_html( $current_ip ) . ') tidak memiliki izin mengakses area ini.</p><p>Silakan hubungi Administrator.</p>',
                '403 Forbidden',
                array( 'response' => 403 )
            );
        }
    }

    /**
     * Cek akses API untuk endpoint sensitif
     * Mencegah API Key/Token digunakan dari IP asing.
     *
     * @param WP_Error|null|bool $result
     * @return WP_Error|null|bool
     */
    public static function enforce_api_access( $result ) {
        // Jika sudah error sebelumnya, biarkan error itu lewat
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Cek apakah endpoint request bertipe "Admin" atau sensitif
        // Di sini kita cek namespace prefix 'sipqu/v1'
        if ( strpos( $_SERVER['REQUEST_URI'], 'wp-json/sipqu/v1' ) !== false ) {
            
            $whitelist_ips = get_option( 'sipqu_admin_ip_whitelist', '' );

            // Jika whitelist kosong, lewatkan (biarkan API publik untuk SWS/Bayar)
            // Catatan: Anda mungkin ingin IP Whitelist hanya untuk API Pengaturan, bukan SWS Public.
            // Namun untuk security maksimal, kita blokir semua jika diaktifkan.
            
            if ( ! empty( $whitelist_ips ) ) {
                $allowed_ips = array_map( 'trim', explode( ',', $whitelist_ips ) );
                $current_ip = self::get_client_ip();

                if ( ! in_array( $current_ip, $allowed_ips ) ) {
                    return new WP_Error( 'ip_blocked', 'IP Address Anda tidak diizinkan mengakses API.', array( 'status' => 403 ) );
                }
            }
        }

        return $result;
    }

    /**
     * Helper: Ambil IP Address Client
     * Menghandle proxy / cloudflare.
     *
     * @return string
     */
    private static function get_client_ip() {
        $ip = '0.0.0.0';

        // Prioritaskan header yang reliable
        if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
            // Cloudflare Support
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        // Validasi format IP
        return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
    }

    /**
     * Helper: Update Whitelist Settings
     * Bisa dipanggil dari Settings Page.
     *
     * @param string $ips_string Comma separated IPs
     */
    public static function update_settings( $ips_string ) {
        // Sanitasi: hanya izinkan karakter IP valid
        $parts = explode( ',', $ips_string );
        $valid_ips = array();

        foreach ( $parts as $part ) {
            $part = trim( $part );
            if ( filter_var( $part, FILTER_VALIDATE_IP ) ) {
                $valid_ips[] = $part;
            }
        }

        $final_value = implode( ', ', $valid_ips );
        update_option( 'sipqu_admin_ip_whitelist', $final_value );
    }
}