<?php
/**
 * Nonce Validator
 *
 * Utility class untuk pembuatan dan verifikasi Nonce (Security Token).
 * Mencegah serangan CSRF pada Form Admin dan REST API.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Nonce_Validator {

    /**
     * Prefix standar untuk semua nonce SIPQU.
     * Struktur nonce di database/log akan seperti: sipqu_{action}
     * Contoh: sipqu_sws_save_invoice
     */
    const PREFIX = 'sipqu_';

    /**
     * Membuat Security Token (Nonce)
     *
     * @param string $action_suffix Aksi unik (tanpa prefix).
     * @return string Token nonce string.
     */
    public static function create( $action_suffix ) {
        return wp_create_nonce( self::get_action( $action_suffix ) );
    }

    /**
     * Verifikasi Nonce untuk Admin Form (POST)
     * Fungsi ini akan men-die (menghentikan script) jika nonce salah.
     *
     * @param string $action_suffix Aksi unik.
     * @param string $field_name  Nama input hidden field (default: 'sipqu_nonce').
     */
    public static function verify_admin( $action_suffix, $field_name = 'sipqu_nonce' ) {
        return check_admin_referer( self::get_action( $action_suffix ), $field_name );
    }

    /**
     * Verifikasi Nonce untuk AJAX Request
     * Fungsi ini akan men-die jika nonce salah, dan mengembalikan JSON error untuk frontend.
     *
     * @param string $action_suffix Aksi unik.
     * @param string $query_arg    Nama parameter nonce (default: 'security' standar jQuery AJAX).
     */
    public static function verify_ajax( $action_suffix, $query_arg = 'security' ) {
        return check_ajax_referer( self::get_action( $action_suffix ), $query_arg );
    }

    /**
     * Verifikasi Nonce untuk REST API
     * Mengambil nonce dari Header HTTP (X-WP-Nonce) secara manual.
     *
     * @param WP_REST_Request $request Request object dari REST API.
     * @param string          $action_suffix Aksi unik.
     * @return bool True jika valid, False jika tidak.
     */
    public static function verify_rest( $request, $action_suffix ) {
        // Ambil nonce dari header (Default WP REST menggunakan header ini)
        $nonce = $request->get_header( 'x-wp-nonce' );

        if ( ! $nonce ) {
            // Fallback: Cek di body request jika header tidak ada
            $nonce = $request->get_param( 'nonce' );
        }

        return wp_verify_nonce( $nonce, self::get_action( $action_suffix ) ) !== false;
    }

    /**
     * Helper: Generate HTML Input Hidden Field
     * Memudahkan penulisan form HTML.
     *
     * @param string $action_suffix Aksi unik.
     * @return string Tag HTML input hidden.
     */
    public static function field( $action_suffix ) {
        return sprintf(
            '<input type="hidden" name="sipqu_nonce" value="%s" />',
            esc_attr( self::create( $action_suffix ) )
        );
    }

    /**
     * Helper: Gabungkan prefix dengan suffix action
     *
     * @param string $suffix
     * @return string
     */
    private static function get_action( $suffix ) {
        return self::PREFIX . $suffix;
    }
}