<?php
/**
 * Rate Limiter
 *
 * Mencegah spam request dan brute force attack menggunakan Transients WordPress.
 * Cocok untuk shared hosting karena tidak memerlukan server eksternal (Redis).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Rate_Limit {

    /**
     * Cek apakah request melebihi batas yang ditentukan.
     *
     * @param string $action_key ID unik untuk jenis limit (misal: 'api_request', 'login_failed').
     * @param int    $limit      Maksimal request yang diperbolehkan.
     * @param int    $period     Periode waktu dalam detik.
     * @return bool True jika diizinkan, False jika user diblokir sementara.
     */
    public static function check( $action_key = 'global', $limit = 60, $period = 60 ) {
        
        // 1. Tentukan Identifier User
        // Jika user login: pakai User ID (akun spesifik)
        // Jika guest: pakai IP Address (berlaku per device)
        $identifier = self::get_identifier();
        
        // 2. Buat Key Transient yang unik
        // Format: sipqu_rate_{action}_{identifier}
        $transient_key = 'sipqu_rate_' . $action_key . '_' . $identifier;
        
        // 3. Ambil data hitungan saat ini
        // Transient akan otomatis terhapus (expire) setelah periode waktu habis
        $current_count = get_transient( $transient_key );
        
        // 4. Jika tidak ada data (Pertama kali / Expired)
        if ( $current_count === false ) {
            // Set hitungan menjadi 1 dan atur kadaluarsa
            set_transient( $transient_key, 1, $period );
            return true;
        }
        
        // 5. Cek apakah sudah melampaui limit
        if ( $current_count >= $limit ) {
            // Batas terlampaui -> TOLAK
            return false;
        }
        
        // 6. Tambah hitungan (+1)
        // Note: Set transient di sini akan reset timer expire ke waktu "sekarang + period".
        // Ini membentuk logika "Burst Window": Anda bisa minta 60x, lalu harus menunggu 1 menit lagi untuk reset.
        $current_count++;
        set_transient( $transient_key, $current_count, $period );
        
        return true;
    }

    /**
     * Mendapatkan sisa request yang diperbolehkan.
     * Berguna untuk mengirimkan header HTTP X-RateLimit-Remaining ke Frontend.
     *
     * @param string $action_key
     * @param int    $limit
     * @return int Sisa jumlah request.
     */
    public static function get_remaining( $action_key = 'global', $limit = 60 ) {
        $identifier = self::get_identifier();
        $transient_key = 'sipqu_rate_' . $action_key . '_' . $identifier;
        
        $current_count = get_transient( $transient_key );
        
        // Jika tidak ada data, berarti sisa penuh
        if ( $current_count === false ) {
            return $limit;
        }
        
        // Hitung selisih
        return max( 0, $limit - $current_count );
    }

    /**
     * Reset hitungan secara manual.
     * Contoh penggunaan: Jika user login sukses, reset limit 'login_failed' agar dia tidak terus diblokir.
     *
     * @param string $action_key
     * @return bool
     */
    public static function reset( $action_key = 'global' ) {
        $identifier = self::get_identifier();
        $transient_key = 'sipqu_rate_' . $action_key . '_' . $identifier;
        
        return delete_transient( $transient_key );
    }

    /**
     * Helper: Generate Identifier (User ID atau IP)
     *
     * @return string
     */
    private static function get_identifier() {
        if ( is_user_logged_in() ) {
            // Gunakan User ID agar 1 user = 1 limit
            return 'user_' . get_current_user_id();
        }
        
        // Gunakan IP Address untuk guest
        return 'ip_' . self::get_client_ip();
    }

    /**
     * Helper: Ambil IP Address Client dengan aman.
     *
     * @return string
     */
    private static function get_client_ip() {
        $ip = '0.0.0.0';
        
        if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return sanitize_text_field( $ip );
    }
}