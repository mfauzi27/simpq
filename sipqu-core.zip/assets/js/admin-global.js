/**
 * SIPQU Admin Global Script
 *
 * Menangani interaksi frontend di Dashboard SIPQU:
 * 1. Input Masking (Format Rupiah)
 * 2. Datepicker Init
 * 3. AJAX Helper Wrapper
 * 4. Custom Toast Notification
 *
 * @package SIPQU_CORE
 */

(function($) {
    "use strict";

    var SIPQU_JS = {

        // Data global dari wp_localize_script (loader.php)
        config: typeof sipquData !== 'undefined' ? sipquData : {},

        init: function() {
            this.setupCurrencyInputs();
            this.setupDatePickers();
            this.setupDeleteConfirmation();
            this.createToastContainer();
            
            // Logika API Headers otomatis
            this.ajaxSetup();
        },

        // ============================================================
        // 1. CURRENCY MASKING (Input Rupiah)
        // ============================================================
        setupCurrencyInputs: function() {
            var self = this;
            
            // Event Handler
            $(document).on('focus', '.sipqu-input-currency', function(e) {
                // Saat Fokus: Hapus format (Rp, titik) agar mudah edit
                var val = $(this).val();
                var clean = self.unformatCurrency(val);
                $(this).val(clean);
            });

            $(document).on('blur', '.sipqu-input-currency', function(e) {
                // Saat Blur (Keluar): Format kembali ke Rupiah
                var val = $(this).val();
                var formatted = self.formatCurrency(val);
                $(this).val(formatted);
                
                // Trigger change agar JS lain tahu value berubah
                $(this).trigger('sipqu:currency_changed');
            });
        },

        formatCurrency: function(value) {
            // 1. Bersihkan semua non-digit
            var number = this.unformatCurrency(value);
            
            if (number === '' || number === 0) return '';
            
            // 2. Format ke Rupiah (Indonesia: Titik pemisah ribuan, Koma desimal)
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(number);
        },

        unformatCurrency: function(value) {
            if (!value) return '';
            // Hapus semua karakter kecuali angka (hapus Rp, titik, spasi)
            return value.toString().replace(/[^0-9]/g, '');
        },

        // ============================================================
        // 2. DATE PICKER INIT
        // ============================================================
        setupDatePickers: function() {
            // Cek apakah jQuery UI Datepicker sudah di-load oleh Core WP
            if ( $.fn.datepicker ) {
                $('.sipqu-datepicker').datepicker({
                    dateFormat: 'dd/mm/yy', // Format Indonesia
                    changeMonth: true,
                    changeYear: true,
                    yearRange: "-100:+10"
                });
            } else {
                // Fallback: Gunakan HTML5 date (browser native)
                // Ubah class jadi text type date jika browser support
                $('.sipqu-datepicker').each(function() {
                    // Ubah placeholder browser native ke format indo
                    $(this).attr('placeholder', 'dd/mm/yyyy');
                });
            }
        },

        // ============================================================
        // 3. AJAX HELPER (Fetch Wrapper)
        // ============================================================
        ajaxSetup: function() {
            var self = this;
            
            // Override $.ajax untuk selalu menyertakan Nonce & Headers SIPQU
            if (typeof $.ajaxSetup !== 'undefined') {
                $.ajaxSetup({
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', self.config.nonce);
                        xhr.setRequestHeader('X-SIPQU-Tenant-Id', self.config.tenant_id);
                    }
                });
            }
        },

        // Helper: AJAX POST dengan Promise
        post: function(endpoint, data) {
            return $.ajax({
                url: this.config.apiUrl + endpoint,
                type: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                dataType: 'json'
            });
        },

        // Helper: AJAX GET
        get: function(endpoint) {
            return $.ajax({
                url: this.config.apiUrl + endpoint,
                type: 'GET',
                dataType: 'json'
            });
        },

        // ============================================================
        // 4. DELETE CONFIRMATION
        // ============================================================
        setupDeleteConfirmation: function() {
            var self = this;
            
            $(document).on('click', '.sipqu-btn-delete', function(e) {
                e.preventDefault();
                var href = $(this).attr('href') || $(this).data('href');
                var msg = $(this).data('confirm') || 'Apakah Anda yakin ingin menghapus data ini?';

                if ( confirm(msg) ) {
                    // Opsional: Bisa tambahkan loading state di sini
                    window.location.href = href;
                }
            });
        },

        // ============================================================
        // 5. TOAST NOTIFICATION (Custom Alert)
        // ============================================================
        createToastContainer: function() {
            if ( $('#sipqu-toast-container').length === 0 ) {
                $('body').append('<div id="sipqu-toast-container" style="position:fixed; bottom:20px; right:20px; z-index:9999;"></div>');
            }
        },

        toast: function(message, type = 'success') {
            var color = type === 'success' ? '#00a32a' : '#d63638';
            
            var toast = $(`
                <div style="background:${color}; color:#fff; padding:12px 20px; border-radius:4px; margin-top:10px; box-shadow:0 2px 5px rgba(0,0,0,0.2); animation: slideIn 0.3s ease-out;">
                    ${message}
                </div>
            `);
            
            $('#sipqu-toast-container').append(toast);
            
            // Hilang otomatis setelah 3 detik
            setTimeout(function() {
                toast.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 3000);
        }
    };

    // Init saat document ready
    $(document).ready(function() {
        SIPQU_JS.init();
    });

    // Expose to Global (Optional untuk dipanggil di script lain)
    window.SIPQU = SIPQU_JS;

})(jQuery);

// CSS Animasi untuk Toast (Disuntikkan via JS agar mandiri)
 $('<style>@keyframes slideIn { from { transform: translateX(100%); opacity:0; } to { transform: translateX(0); opacity:1; } }</style>').appendTo('head');