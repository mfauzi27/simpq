<?php
/**
 * Capability Checker (RBAC)
 *
 * Mengatur hak akses user berdasarkan Role SIPQU.
 * Menjamin user hanya bisa melakukan aksi yang sesuai dengan perannya.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Capability {

    /**
     * Peta Hak Akses (Permission Map)
     * Masing-masing role memiliki array string permission.
     * 
     * Format string: {modul}.{aksi}
     * Contoh: 'sws.view' (Melihat SWS), 'finance.delete' (Hapus Jurnal)
     */
    private static $permissions_map = array(
        
        // 1. SIPQU SUPER ADMIN (Owner / Pengurus Yayasan)
        // Akses penuh ke semua modul.
        'sipqu_super_admin' => array(
            '*' // Wildcard: Boleh akses semua
        ),

        // 2. ADMIN LPQ (Kepala Sekolah)
        // Bisa mengelola user, setting, dan melihat semua laporan.
        'sipqu_admin' => array(
            'dashboard.view',
            
            // Students
            'student.view', 'student.create', 'student.update', 'student.delete',
            
            // SWS (Hak akses penuh)
            'sws.view', 'sws.create', 'sws.edit', 'sws.delete', 'sws.settings',
            
            // Finance (Lihat & Approve, tapi hati-hati delete)
            'finance.view', 'finance.create', 'finance.approve',
            
            // Laporan
            'report.view', 'report.export',
            
            // Settings
            'system.settings',
        ),

        // 3. BENDAHARA (Keuangan)
        // Fokus pada input dan pembayaran. Dilarang menghapus data keuangan.
        'sipqu_bendahara' => array(
            'dashboard.view',
            
            // SWS
            'sws.view', 'sws.create', 'sws.edit', 'sws.pay', // Bisa input bayar
            
            // Finance (Bisa input jurnal manual, TIDAK BISA delete/approve sendiri)
            'finance.view', 'finance.create',
            
            // Laporan (Tapi tidak boleh edit data laporan)
            'report.view', 'report.export',
        ),

        // 4. PENGURUS / OPERASIONAL
        // Bisa melihat data, input aset, tapi tidak boleh menyentuh jurnal.
        'sipqu_pengurus' => array(
            'dashboard.view',
            'student.view',
            'asset.view', 'asset.create', 'asset.update',
            'report.view',
        ),

        // 5. ASATIDZ (Guru)
        // Fokus pada akademik.
        'sipqu_asatidz' => array(
            'dashboard.view',
            'student.view', // Hanya melihat daftar santri
            'attendance.view', 'attendance.input', // Isi presensi
            'honor.view', // Melihat gaji sendiri (logika filter di modul)
        ),

        // 6. WALI SANTRI (Parent)
        // Hanya view data anak sendiri (Logika filter data dilakukan di query, permission ini hanya dasar)
        'sipqu_wali' => array(
            'student.view',
            'sws.view', // Melihat tagihan anak
            'attendance.view',
        )
    );

    /**
     * Pengecekan Hak Akses Utama.
     *
     * @param string $permission String permission (misal: 'sws.view').
     * @param bool   $abort       Jika true, akan menghentikan skrip (wp_die) jika akses ditolak.
     *                             Jika false, hanya mengembalikan boolean.
     * @return bool True jika diizinkan, False jika ditolak.
     */
    public static function check( $permission, $abort = true ) {
        
        // 1. Ambil Role SIPQU user saat ini dari Context
        $current_role = SIPQU_Tenant_Context::role();

        // 2. Jika user belum login atau role tidak valid
        if ( empty( $current_role ) ) {
            if ( $abort ) self::abort( $permission );
            return false;
        }

        // 3. Ambil list permission untuk role tersebut
        $role_permissions = self::get_role_permissions( $current_role );

        // 4. Logika Validasi
        $is_allowed = false;

        // Cek apakah role memiliki wildcard '*'
        if ( in_array( '*', $role_permissions ) ) {
            $is_allowed = true;
        } 
        // Cek apakah permission ada di list role
        elseif ( in_array( $permission, $role_permissions ) ) {
            $is_allowed = true;
        }

        // 5. Jika TIDAK DIIZINKAN
        if ( ! $is_allowed ) {
            // Catat ke Audit Log sebagai potensi pelanggaran keamanan
            if ( function_exists( 'SIPQU_Audit_Logger' ) ) {
                SIPQU_Audit_Logger::log( 
                    'security', 
                    'access_denied', 
                    null, 
                    array( 'role' => $current_role ), 
                    array( 'requested_permission' => $permission ) 
                );
            }

            if ( $abort ) {
                self::abort( $permission );
            }
            return false;
        }

        // 6. DIIZINKAN
        return true;
    }

    /**
     * Menghentikan eksekusi script dengan pesan error 403.
     */
    private static function abort( $permission ) {
        // Jika request REST API, return JSON Error
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            wp_send_json_error( 
                array( 
                    'message' => 'Anda tidak memiliki izin untuk melakukan aksi ini.', 
                    'code' => 'rest_forbidden',
                    'permission' => $permission
                ), 
                403 
            );
        }

        // Jika di halaman Admin, tampilkan pesan HTML
        wp_die(
            '<h1>Akses Ditolak</h1><p>Anda tidak memiliki izin (<code>' . esc_html( $permission ) . '</code>) untuk mengakses halaman ini.</p>',
            '403 Forbidden',
            array( 'response' => 403 )
        );
    }

    /**
     * Mengambil daftar permission berdasarkan role.
     * (Bisa diextend nanti untuk ambil dari database options agar dinamis).
     *
     * @param string $role
     * @return array
     */
    private static function get_role_permissions( $role ) {
        // Cek apakah role ada di map
        if ( isset( self::$permissions_map[ $role ] ) ) {
            return self::$permissions_map[ $role ];
        }

        // Jika role tidak dikenali (misal subscriber), return kosong
        return array();
    }

    /**
     * Shortcut: Cek apakah user adalah Admin / Super Admin
     */
    public static function is_admin() {
        $role = SIPQU_Tenant_Context::role();
        return ( $role === 'sipqu_super_admin' || $role === 'sipqu_admin' );
    }
    
    /**
     * Shortcut: Cek apakah user adalah Bendahara
     */
    public static function is_bendahara() {
        return SIPQU_Tenant_Context::role() === 'sipqu_bendahara';
    }

    /**
     * Shortcut: Cek apakah user adalah Asatidz
     */
    public static function is_asatidz() {
        return SIPQU_Tenant_Context::role() === 'sipqu_asatidz';
    }
}