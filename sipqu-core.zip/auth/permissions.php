<?php
/**
 * Permissions Helper
 *
 * Helper untuk query dan mengecek permission user tanpa 
 * melakukan blocking (wp_die). Cocok untuk keperluan UI 
 * (menyembunyikan tombol, menu).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Permissions {

    /**
     * Mengambil daftar lengkap permission (capability) milik user saat ini.
     * Mengambil dari Map Config + Capability manual WP.
     *
     * @return array List string permissions.
     */
    public static function get_current_user_permissions() {
        // Cek apakah user login
        if ( ! is_user_logged_in() ) {
            return array();
        }

        $user_id = get_current_user_id();
        return self::get_user_permissions( $user_id );
    }

    /**
     * Mengambil permission user spesifik berdasarkan ID.
     * Menggabungkan permission dari Role SIPQU + Default WP Roles.
     *
     * @param int $user_id
     * @return array
     */
    public static function get_user_permissions( $user_id ) {
        
        // 1. Ambil role SIPQU user saat ini
        $current_role = SIPQU_Tenant_Context::role();

        // 2. Ambil peta permission dari config
        $permission_map = sipqu_get_permission_map();

        // 3. Ambil list permission role tersebut
        $role_perms = isset( $permission_map[ $current_role ] ) 
                      ? $permission_map[ $current_role ] 
                      : array();

        // 4. Cek Wildcard
        if ( in_array( '*', $role_perms ) ) {
            // Jika wildcard, kembalikan semua permission yang terdaftar di map
            // (Kumpulkan semua unik value dari array map)
            $all_perms = array();
            foreach ( $permission_map as $r => $p ) {
                if ( is_array( $p ) ) {
                    foreach ( $p as $perm ) {
                        if ( $perm !== '*' ) $all_perms[ $perm ] = true;
                    }
                }
            }
            return array_keys( $all_perms );
        }

        return $role_perms;
    }

    /**
     * Cek apakah user memiliki permission spesifik.
     * Mengembalikan BOOLEAN (tidak die).
     * Cocok untuk: if ( has('finance.create') ) { show_button(); }
     *
     * @param string $permission Capability string
     * @return bool
     */
    public static function has( $permission ) {
        if ( ! is_user_logged_in() ) {
            return false;
        }

        // 1. Ambil permission user saat ini
        $user_perms = self::get_current_user_permissions();

        // 2. Cek Wildcard
        if ( in_array( '*', $user_perms ) ) {
            return true;
        }

        // 3. Cek Permission Spesifik
        if ( in_array( $permission, $user_perms ) ) {
            return true;
        }

        return false;
    }

    /**
     * Cek apakah User ID tertentu memiliki permission.
     * Berguna untuk admin mengecek hak akses user lain.
     *
     * @param int    $user_id
     * @param string $permission
     * @return bool
     */
    public static function user_can( $user_id, $permission ) {
        // Kita perlu simulasi context untuk user ini
        // Ini agak kompleks karena Tenant_Context global dipakai untuk current user.
        // Untuk simplifikasi, kita ambil dari data mapping database saja.
        
        global $wpdb;
        $table = SIPQU_DB::table('user_tenants');
        
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT role FROM {$table} WHERE user_id = %d AND status = 'active' LIMIT 1",
            $user_id
        ) );

        if ( ! $row ) {
            return false;
        }

        // Cek permission berdasarkan role di database
        $permission_map = sipqu_get_permission_map();
        $role_perms = isset( $permission_map[ $row->role ] ) 
                      ? $permission_map[ $row->role ] 
                      : array();

        if ( in_array( '*', $role_perms ) ) {
            return true;
        }

        return in_array( $permission, $role_perms );
    }

    /**
     * Mengambil Label User-Friendly untuk permission string.
     * Helper untuk UI Permissions.
     *
     * @param string $permission
     * @return string
     */
    public static function get_label( $permission ) {
        $labels = array(
            // System
            'dashboard.view'      => 'Lihat Dashboard',
            
            // Students
            'student.view'        => 'Lihat Data Santri',
            'student.create'      => 'Tambah Santri',
            'student.update'      => 'Edit Santri',
            'student.delete'      => 'Hapus Santri',
            
            // Finance
            'finance.view'        => 'Lihat Keuangan',
            'finance.create'      => 'Input Transaksi',
            'finance.update'      => 'Edit Transaksi',
            'finance.delete'      => 'Hapus Transaksi',
            'finance.approve'     => 'Setujui Transaksi',
            
            // SWS
            'sws.view'            => 'Lihat Tagihan SWS',
            'sws.create'          => 'Buat Tagihan',
            'sws.edit'            => 'Edit Tagihan',
            'sws.delete'          => 'Hapus Tagihan',
            'sws.pay'             => 'Input Pembayaran',
            'sws.settings'        => 'Pengaturan SWS',
            
            // Reports
            'report.view'         => 'Lihat Laporan',
            'report.export'       => 'Export Laporan',
            'report.manage'       => 'Kelola Template Laporan',
            
            // Settings
            'system.settings'     => 'Pengaturan Sistem',
            'system.manage_users' => 'Kelola Pengguna',
            'audit.view'          => 'Lihat Audit Log',
        );

        return isset( $labels[ $permission ] ) ? $labels[ $permission ] : $permission;
    }
}