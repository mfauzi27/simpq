<?php
/**
 * Roles Manager
 *
 * Menangani pembuatan dan manajemen Role (Peran) WordPress 
 * yang digunakan oleh SIPQU (Super Admin, Admin, Bendahara, dll).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Roles {

    /**
     * Inisialisasi Role saat plugin di-aktivasi.
     * Memanggil fungsi pembuatan role dan update role admin default.
     *
     * @return void
     */
    public static function init() {
        self::create_sipqu_roles();
        self::add_capability_to_default_admin();
    }

    /**
     * Membuat Role Khusus SIPQU jika belum ada.
     * Role yang sudah ada tidak akan ditimpa (safety).
     */
    private static function create_sipqu_roles() {

        // 1. SIPQU SUPER ADMIN (Pemilik Yayasan)
        if ( ! get_role( 'sipqu_super_admin' ) ) {
            add_role(
                'sipqu_super_admin',
                __( 'SIPQU Super Admin', 'sipqu-core' ),
                array(
                    'read'           => true,  // Bisa lihat dashboard
                    'manage_sipqu'    => true,  // Cap utama SIPQU
                    'delete_users'    => true,  // Bisa hapus user WP
                    'manage_options' => true   // Bisa atur setting WP
                )
            );
        }

        // 2. ADMIN LPQ (Kepala Sekolah)
        if ( ! get_role( 'sipqu_admin' ) ) {
            add_role(
                'sipqu_admin',
                __( 'Admin LPQ', 'sipqu-core' ),
                array(
                    'read'        => true,
                    'manage_sipqu'=> true
                )
            );
        }

        // 3. BENDAHARA (Keuangan)
        if ( ! get_role( 'sipqu_bendahara' ) ) {
            add_role(
                'sipqu_bendahara',
                __( 'Bendahara LPQ', 'sipqu-core' ),
                array(
                    'read'        => true,
                    'manage_sipqu'=> true
                )
            );
        }

        // 4. PENGURUS / OPERASIONAL
        if ( ! get_role( 'sipqu_pengurus' ) ) {
            add_role(
                'sipqu_pengurus',
                __( 'Pengurus LPQ', 'sipqu-core' ),
                array(
                    'read'        => true,
                    'manage_sipqu'=> true
                )
            );
        }

        // 5. ASATIDZ (Guru)
        if ( ! get_role( 'sipqu_asatidz' ) ) {
            add_role(
                'sipqu_asatidz',
                __( 'Asatidz / Guru', 'sipqu-core' ),
                array(
                    'read' => true
                )
            );
        }

        // 6. WALI SANTRI (Orang Tua)
        if ( ! get_role( 'sipqu_wali' ) ) {
            add_role(
                'sipqu_wali',
                __( 'Wali Santri', 'sipqu-core' ),
                array(
                    'read' => true
                )
            );
        }
    }

    /**
     * Memberikan hak akses SIPQU kepada Role Administrator bawaan WordPress.
     * Ini memungkinkan Developer/Super Admin WP mengakses SIPQU
     * tanpa perlu membuat role baru.
     */
    private static function add_capability_to_default_admin() {
        
        // Ambil role Administrator
        $admin_role = get_role( 'administrator' );

        if ( $admin_role ) {
            // Tambahkan cap 'manage_sipqu' jika belum ada
            if ( ! $admin_role->has_cap( 'manage_sipqu' ) ) {
                $admin_role->add_cap( 'manage_sipqu' );
            }
        }
    }

    /**
     * Fungsi Helper untuk menghapus Role (Opsional, untuk Uninstall/Reset).
     * Hati-hati: Menghapus role akan menghapus role dari semua user yang memilikinya.
     * User tersebut akan kembali menjadi 'subscriber' atau role default.
     *
     * @return void
     */
    public static function remove_sipqu_roles() {
        
        $sipqu_roles = array(
            'sipqu_super_admin',
            'sipqu_admin',
            'sipqu_bendahara',
            'sipqu_pengurus',
            'sipqu_asatidz',
            'sipqu_wali'
        );

        foreach ( $sipqu_roles as $role_slug ) {
            if ( get_role( $role_slug ) ) {
                remove_role( $role_slug );
            }
        }

        // Hapus cap dari Admin WP
        $admin_role = get_role( 'administrator' );
        if ( $admin_role && $admin_role->has_cap( 'manage_sipqu' ) ) {
            $admin_role->remove_cap( 'manage_sipqu' );
        }
    }
}