<?php
/**
 * Access Middleware
 *
 * Lapisan keamanan untuk REST API. Menggabungkan pengecekan
 * Auth, Tenant Context, Permission, dan Rate Limit dalam satu method.
 * Mengembalikan WP_Error jika akses ditolak.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Access_Middleware {

    /**
     * Verifikasi akses untuk request API.
     * Fungsi ini dipanggil di 'permission_callback' saat registrasi route.
     *
     * @param WP_REST_Request $request Request object.
     * @param string          $permission Capability yang dibutuhkan (misal: 'sws.view').
     * @return true|WP_Error True jika boleh, WP_Error jika ditolak.
     */
    public static function verify( $request, $permission ) {

        // 1. CHECK: Authentication (Login Status)
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 
                'rest_forbidden', 
                'Silakan login untuk mengakses resource ini.', 
                array( 'status' => 401 ) // Unauthorized
            );
        }

        // 2. CHECK: Rate Limiting (Anti-Spam)
        // Cek apakah user sudah melewati batas request API per menit
        if ( ! SIPQU_Rate_Limit::check( 'api_call', SIPQU_API_RATE_LIMIT, 60 ) ) {
            return new WP_Error( 
                'rest_throttled', 
                'Terlalu banyak request. Silakan coba lagi dalam 1 menit.', 
                array( 'status' => 429 ) 
            );
        }

        // 3. CHECK: Tenant Context
        // User harus punya Tenant ID aktif (bukan 0 atau NULL)
        $tenant_id = SIPQU_Tenant_Context::tenant_id();
        if ( empty( $tenant_id ) ) {
            return new WP_Error( 
                'rest_forbidden', 
                'User ini belum dipetakan ke Lembaga (Tenant) manapun.', 
                array( 'status' => 403 ) 
            );
        }

        // 4. CHECK: Permissions (Capability)
        // Menggunakan Capability Checker inti, tapi jangan 'die' (abort)
        if ( ! SIPQU_Capability::check( $permission, false ) ) {
            // Catat ke Audit Log jika mencoba akses terlarang
            if ( function_exists( 'SIPQU_Audit_Logger' ) ) {
                SIPQU_Audit_Logger::log( 'security', 'api_access_denied', null, null, array( 'permission' => $permission ) );
            }

            return new WP_Error( 
                'rest_forbidden', 
                'Anda tidak memiliki izin (' . $permission . ') untuk aksi ini.', 
                array( 'status' => 403 ) // Forbidden
            );
        }

        // 5. SEMUA LULUS
        return true;
    }

    /**
     * Verifikasi Sederhana Hanya (Cek Login & Tenant, Bypass Permission)
     * Digunakan untuk endpoint publik yang butuh context (misal: Get Profile Sendiri)
     */
    public static function verify_auth_only( $request ) {
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'rest_forbidden', 'Silakan login.', array( 'status' => 401 ) );
        }

        if ( empty( SIPQU_Tenant_Context::tenant_id() ) ) {
            return new WP_Error( 'rest_forbidden', 'Konteks Tenant tidak ditemukan.', array( 'status' => 403 ) );
        }

        return true;
    }
}