<?php
/**
 * Setup Page - Initial Tenant Wizard
 *
 * Halaman untuk membuat LPQ/Tenant pertama kali dan memetakan Admin.
 * Halaman ini akan otomatis tersembunyi jika Tenant sudah ada.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

// ============================================================
// 1. REGISTER MENU
// ============================================================

add_action('admin_menu', 'sipqu_register_setup_page_menu');

function sipqu_register_setup_page_menu() {
    // Cek apakah setup sudah pernah dilakukan (ada tenant di database?)
    global $wpdb;
    $tenant_count = $wpdb->get_var("SELECT COUNT(*) FROM " . SIPQU_DB::table('tenants'));

    // Jika sudah ada tenant, jangan tampilkan menu Setup
    if ( $tenant_count > 0 ) {
        return;
    }

    add_menu_page(
        'Setup SIPQU',              // Page Title
        'Setup SIPQU',              // Menu Title
        'manage_options',            // Capability
        'sipqu-setup',               // Menu Slug
        'sipqu_render_setup_page',   // Callback function
        'dashicons-admin-home',      // Icon
        3                            // Position (Tinggi, di bawah Dashboard)
    );
}

// ============================================================
// 2. HANDLE FORM SUBMISSION
// ============================================================

add_action('admin_init', 'sipqu_handle_setup_submission');

function sipqu_handle_setup_submission() {
    // 1. Cek apakah form disubmit
    if ( ! isset( $_POST['sipqu_setup_submit'] ) ) {
        return;
    }

    // 2. Validasi Nonce (Security)
    if ( ! isset( $_POST['sipqu_setup_nonce'] ) || ! wp_verify_nonce( $_POST['sipqu_setup_nonce'], 'sipqu_setup_action' ) ) {
        wp_die( 'Security check failed. Please try again.' );
    }

    // 3. Cek Capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'You do not have permission to perform this action.' );
    }

    // 4. Ambil & Sanitasi Data
    $tenant_name = sanitize_text_field( $_POST['tenant_name'] );
    $tenant_code = sanitize_text_field( $_POST['tenant_code'] );
    $address      = sanitize_textarea_field( $_POST['address'] );
    $phone        = sanitize_text_field( $_POST['phone'] );

    // Validasi Input Sederhana
    if ( empty( $tenant_name ) || empty( $tenant_code ) ) {
        add_settings_error( 'sipqu_setup', 'empty_fields', 'Nama LPQ dan Kode wajib diisi.', 'error' );
        return;
    }

    global $wpdb;
    $prefix = $wpdb->prefix . 'sipqu_';

    // 5. Transaksi Database (Insert Tenant + Branch + Map User)
    // Kita mulai transaksi untuk memastikan konsistensi
    $wpdb->query( 'START TRANSACTION' );

    try {
        // A. Insert Tenant
        $tenant_data = array(
            'tenant_code' => strtoupper( $tenant_code ), // Format uppercase
            'tenant_name' => $tenant_name,
            'status'      => 'active',
            'created_at'  => current_time( 'mysql' )
        );

        $wpdb->insert( $prefix . 'tenants', $tenant_data );
        $tenant_id = $wpdb->insert_id;

        if ( ! $tenant_id ) {
            throw new Exception( 'Gagal membuat data LPQ. Mungkin Kode LPQ sudah digunakan.' );
        }

        // B. Insert Branch (Default Main Branch)
        $branch_data = array(
            'tenant_id'   => $tenant_id,
            'branch_name' => 'Pusat (Utama)',
            'address'     => $address,
            'phone'       => $phone,
            'is_main'     => 1,
            'created_at'  => current_time( 'mysql' )
        );

        $wpdb->insert( $prefix . 'branches', $branch_data );
        $branch_id = $wpdb->insert_id;

        // C. Map Current User ke Tenant ini
        $current_user_id = get_current_user_id();
        $user_map_data = array(
            'user_id'    => $current_user_id,
            'tenant_id'  => $tenant_id,
            'branch_id'  => $branch_id,
            'role'       => 'sipqu_super_admin',
            'status'     => 'active',
            'created_at' => current_time( 'mysql' )
        );

        $wpdb->insert( $prefix . 'user_tenants', $user_map_data );

        // D. Seed Initial COA (Chart of Accounts) - Simple Seed
        // Memastikan tabel akun untuk keuangan ada minimal 101 (Kas) & 401 (Pendapatan)
        if ( ! $wpdb->get_var("SELECT id FROM {$prefix}accounts WHERE code = '101'") ) {
            $wpdb->insert( $prefix . 'accounts', array(
                'tenant_id' => $tenant_id,
                'code'      => '101',
                'name'      => 'Kas Tunai',
                'type'      => 'asset',
                'created_at' => current_time('mysql')
            ));
            $wpdb->insert( $prefix . 'accounts', array(
                'tenant_id' => $tenant_id,
                'code'      => '401',
                'name'      => 'Pendapatan Operasional',
                'type'      => 'income',
                'created_at' => current_time('mysql')
            ));
        }

        // Commit Transaksi
        $wpdb->query( 'COMMIT' );

        // Sukses: Redirect ke Dashboard Utama (Settings)
        wp_redirect( admin_url( 'admin.php?page=sipqu-settings&setup_success=1' ) );
        exit;

    } catch ( Exception $e ) {
        // Rollback jika ada error
        $wpdb->query( 'ROLLBACK' );
        add_settings_error( 'sipqu_setup', 'db_error', 'Terjadi kesalahan: ' . $e->getMessage(), 'error' );
    }
}

// ============================================================
// 3. RENDER UI (HTML)
// ============================================================

function sipqu_render_setup_page() {
    // Tampilkan pesan error jika ada
    settings_errors( 'sipqu_setup' );
    ?>
    <div class="wrap">
        <div class="card" style="max-width: 600px; margin-top: 20px; padding: 20px;">
            <h1 style="margin-top: 0;">🎉 Selamat Datang di SIPQU</h1>
            <p>
                Terima kasih telah menginstal <strong>SIPQU v1.0</strong>.<br>
                Mari kita buat profil Lembaga Pendidikan (LPQ) Anda untuk memulai sistem.
            </p>

            <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">

            <form method="post" action="">
                <?php wp_nonce_field( 'sipqu_setup_action', 'sipqu_setup_nonce' ); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="tenant_name">Nama Lembaga (LPQ) <span class="description">(wajib)</span></label></th>
                        <td>
                            <input type="text" name="tenant_name" id="tenant_name" class="regular-text" value="" required placeholder="Contoh: TPQ Al-Amin">
                            <p class="description">Nama resmi lembaga yang akan muncul di laporan.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tenant_code">Kode Lembaga <span class="description">(wajib, unik)</span></label></th>
                        <td>
                            <input type="text" name="tenant_code" id="tenant_code" class="regular-text" value="" required placeholder="Contoh: TPQ001" maxlength="10">
                            <p class="description">Kode unik singkat untuk sistem (Maks 10 karakter).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="address">Alamat Lengkap</label></th>
                        <td>
                            <textarea name="address" id="address" class="large-text" rows="3" placeholder="Alamat jalan, kelurahan, kecamatan..."></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="phone">No. Telepon / WA</label></th>
                        <td>
                            <input type="tel" name="phone" id="phone" class="regular-text" placeholder="0812...">
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="sipqu_setup_submit" id="submit" class="button button-primary button-large" value="Buat Profil Lembaga & Mulai">
                </p>
            </form>
        </div>
    </div>
    <?php
}