<?php
/**
 * Settings Page - Main Configuration
 *
 * Halaman pengaturan utama SIPQU (Profile LPQ, Cabang, Users).
 * Menggunakan Pattern MVC (Mengambil data dari Manager Class).
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

// ============================================================
// 1. REGISTER MENU
// ============================================================

add_action('admin_menu', 'sipqu_register_settings_page');

function sipqu_register_settings_page() {
    // Submenu di bawah menu utama SIPQU (asumsi menu utama ada di loader)
    add_submenu_page(
        'sipqu',                     // Parent slug
        'Pengaturan SIPQU',          // Page Title
        'Pengaturan',                // Menu Title
        'manage_options',            // Capability
        'sipqu-settings',            // Menu Slug
        'sipqu_render_settings_page' // Callback
    );
}

// ============================================================
// 2. HANDLE FORM SUBMISSIONS (CONTROLLER LOGIC)
// ============================================================

add_action('admin_init', 'sipqu_handle_settings_save');

function sipqu_handle_settings_save() {
    
    // 1. Handle Update Profil Tenant
    if ( isset( $_POST['sipqu_save_profile'] ) ) {
        
        // Security: Validasi Nonce
        if ( ! isset( $_POST['sipqu_profile_nonce'] ) || ! wp_verify_nonce( $_POST['sipqu_profile_nonce'], 'sipqu_profile_action' ) ) {
            return;
        }

        // Capability: Cek izin
        if ( ! current_user_can( 'manage_sipqu' ) ) {
            return;
        }

        // Logic: Ambil ID tenant dan kirim data ke Manager
        $tenant_id = SIPQU_Tenant_Context::tenant_id();
        if ( ! $tenant_id ) return;

        // ✅ CALL MANAGER: Update data tenant
        // Manager akan menangani sanitasi dan update database
        $result = SIPQU_Tenant_Manager::update( $tenant_id, $_POST );

        if ( $result !== false ) {
            add_settings_error( 'sipqu_settings', 'profile_updated', 'Profil LPQ berhasil diperbarui.', 'updated' );
        } else {
            add_settings_error( 'sipqu_settings', 'profile_error', 'Gagal memperbarui profil.', 'error' );
        }
    }

    // 2. Handle Tambah Cabang Baru
    if ( isset( $_POST['sipqu_add_branch'] ) ) {
        
        // Security: Validasi Nonce
        if ( ! isset( $_POST['sipqu_branch_nonce'] ) || ! wp_verify_nonce( $_POST['sipqu_branch_nonce'], 'sipqu_branch_action' ) ) {
            return;
        }

        // Capability: Cek izin
        if ( ! current_user_can( 'manage_sipqu' ) ) {
            return;
        }

        // Logic: Kirim data form ke Manager untuk di-insert
        // ✅ CALL MANAGER: Insert data branch baru
        // Manager otomatis memasukkan tenant_id user saat ini
        $branch_id = SIPQU_Branch_Manager::create( $_POST );

        if ( $branch_id ) {
            add_settings_error( 'sipqu_settings', 'branch_added', 'Cabang baru berhasil ditambahkan.', 'updated' );
        } else {
            add_settings_error( 'sipqu_settings', 'branch_error', 'Gagal menambah cabang.', 'error' );
        }
    }
}

// ============================================================
// 3. RENDER UI (VIEW)
// ============================================================

function sipqu_render_settings_page() {
    
    // Cek apakah user punya akses ke tenant
    $tenant_id = SIPQU_Tenant_Context::tenant_id();
    if ( ! $tenant_id ) {
        echo '<div class="wrap"><h1>Akses Ditolak</h1><p>User ini tidak memiliki aktifitas Tenant.</p></div>';
        return;
    }

    // ✅ CALL MANAGER: Ambil data dari database, bukan raw SQL
    // Ini membuat kode lebih bersih dan aman
    $current_tenant = SIPQU_Tenant_Manager::get( $tenant_id );
    $branches       = SIPQU_Branch_Manager::get_all_by_tenant( $tenant_id );

    // Tentukan Tab Aktif dari URL
    $active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'profile';

    ?>
    <div class="wrap">
        <h1>Pengaturan SIPQU</h1>
        
        <?php settings_errors( 'sipqu_settings' ); ?>

        <h2 class="nav-tab-wrapper">
            <a href="?page=sipqu-settings&tab=profile" class="nav-tab <?php echo $active_tab == 'profile' ? 'nav-tab-active' : ''; ?>">Profil Lembaga</a>
            <a href="?page=sipqu-settings&tab=branches" class="nav-tab <?php echo $active_tab == 'branches' ? 'nav-tab-active' : ''; ?>">Kelola Cabang</a>
            <a href="?page=sipqu-settings&tab=users" class="nav-tab <?php echo $active_tab == 'users' ? 'nav-tab-active' : ''; ?>">Pengguna & Izin</a>
        </h2>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <?php
            switch ( $active_tab ) {
                case 'branches':
                    sipqu_render_branches_tab( $branches );
                    break;
                case 'users':
                    sipqu_render_users_tab();
                    break;
                case 'profile':
                default:
                    sipqu_render_profile_tab( $current_tenant );
                    break;
            }
            ?>
        </div>
    </div>
    <?php
}

// ------------------------------------------------------------
// TAB 1: PROFIL
// ------------------------------------------------------------
function sipqu_render_profile_tab( $tenant ) {
    ?>
    <h3>Edit Profil LPQ</h3>
    <form method="post" action="">
        <?php wp_nonce_field( 'sipqu_profile_action', 'sipqu_profile_nonce' ); ?>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="tenant_name">Nama Lembaga</label></th>
                <td>
                    <input type="text" name="tenant_name" id="tenant_name" class="regular-text" value="<?php echo esc_attr( $tenant->tenant_name ); ?>" required>
                    <p class="description">Nama resmi lembaga.</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="tenant_code">Kode Lembaga</label></th>
                <td>
                    <input type="text" class="regular-text" value="<?php echo esc_attr( $tenant->tenant_code ); ?>" disabled style="background: #eee;">
                    <p class="description">Kode identifikasi tidak dapat diubah.</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="address">Alamat Lengkap</label></th>
                <td>
                    <textarea name="address" id="address" class="large-text" rows="4"><?php echo esc_textarea( $tenant->address ); ?></textarea>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="phone">No. Telepon / WA</label></th>
                <td>
                    <input type="tel" name="phone" id="phone" class="regular-text" value="<?php echo esc_attr( $tenant->phone ); ?>">
                </td>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" name="sipqu_save_profile" class="button button-primary" value="Simpan Perubahan">
        </p>
    </form>
    <?php
}

// ------------------------------------------------------------
// TAB 2: CABANG (BRANCHES)
// ------------------------------------------------------------
function sipqu_render_branches_tab( $branches ) {
    ?>
    <h3>Daftar Cabang</h3>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Nama Cabang</th>
                <th>Alamat</th>
                <th>Tipe</th>
                <th>Tanggal Dibuat</th>
            </tr>
        </thead>
        <tbody>
            <?php if ( $branches ) : ?>
                <?php foreach ( $branches as $branch ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $branch->branch_name ); ?></strong></td>
                    <td><?php echo esc_html( $branch->address ); ?></td>
                    <td>
                        <?php if ( $branch->is_main ) : ?>
                            <span style="color: green; font-weight: bold;">Pusat (Utama)</span>
                        <?php else : ?>
                            Cabang Biasa
                        <?php endif; ?>
                    </td>
                    <td><?php echo SIPQU_Formatter::date( $branch->created_at ); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr><td colspan="4">Belum ada cabang tambahan.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <hr style="margin: 30px 0;">

    <h3>Tambah Cabang Baru</h3>
    <form method="post" action="">
        <?php wp_nonce_field( 'sipqu_branch_action', 'sipqu_branch_nonce' ); ?>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="branch_name">Nama Cabang</label></th>
                <td><input type="text" name="branch_name" id="branch_name" class="regular-text" required placeholder="Contoh: Cabang Timur"></td>
            </tr>
            <tr>
                <th scope="row"><label for="branch_address">Alamat Cabang</label></th>
                <td><textarea name="address" id="branch_address" class="large-text" rows="2"></textarea></td>
            </tr>
            <tr>
                <th scope="row"><label for="branch_phone">No. Telp Cabang</label></th>
                <td><input type="tel" name="phone" id="branch_phone" class="regular-text"></td>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" name="sipqu_add_branch" class="button button-secondary" value="Tambah Cabang">
        </p>
    </form>
    <?php
}

// ------------------------------------------------------------
// TAB 3: USERS (MENGGUNAKAN RAW SQL SEMENTARA)
// ------------------------------------------------------------
function sipqu_render_users_tab() {
    global $wpdb; // Masih pakai global $wpdb karena User Manager belum dibuat
    $tenant_id = SIPQU_Tenant_Context::tenant_id();

    // Ambil user mapping
    $users = $wpdb->get_results( $wpdb->prepare(
        "SELECT ut.*, u.display_name, u.user_email 
         FROM " . SIPQU_DB::table('user_tenants') . " ut
         JOIN {$wpdb->users} u ON ut.user_id = u.ID
         WHERE ut.tenant_id = %d",
        $tenant_id
    ));
    ?>
    <h3>Pengguna yang memiliki akses LPQ ini</h3>
    <p class="description">Untuk menambahkan pengguna baru, silakan buka menu <strong>Users</strong> di panel WordPress.</p>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Nama User</th>
                <th>Email</th>
                <th>Role di SIPQU</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ( $users ) : ?>
                <?php foreach ( $users as $u ) : ?>
                <tr>
                    <td><?php echo esc_html( $u->display_name ); ?></td>
                    <td><?php echo esc_html( $u->user_email ); ?></td>
                    <td><span class="badge"><?php echo strtoupper( str_replace('_', ' ', $u->role) ); ?></span></td>
                    <td>
                        <?php if ( $u->status === 'active' ) : ?>
                            <span style="color: green;">Aktif</span>
                        <?php else : ?>
                            <span style="color: red;">Nonaktif</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr><td colspan="4">Belum ada pengguna yang dipetakan.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php
}