<?php
// CLI test: render settings page HTML as admin
// Usage: C:\xampp\php\php.exe render_settings_test.php

$WP_LOAD = 'C:/xampp/htdocs/wordpress/wp-load.php';
if ( ! file_exists( $WP_LOAD ) ) {
    echo "Cannot find wp-load.php at {$WP_LOAD}\n";
    exit(1);
}

require_once $WP_LOAD;

$plugin_main = __DIR__ . '/sipqu-core.php';
if ( ! file_exists( $plugin_main ) ) {
    echo "Cannot find plugin main file: {$plugin_main}\n";
    exit(1);
}

require_once $plugin_main;

// Ensure admin role has the capability
if ( class_exists( 'SIPQU_Roles' ) ) {
    SIPQU_Roles::init();
}

// Set current user to user ID 1 (assumed admin)
if ( function_exists( 'wp_set_current_user' ) ) {
    wp_set_current_user( 1 );
}

// Force tenant context so settings page doesn't show access denied
if ( class_exists( 'SIPQU_Tenant_Context' ) ) {
    SIPQU_Tenant_Context::set( [ 'tenant_id' => 1, 'branch_id' => 1, 'role' => 'sipqu_super_admin' ] );
}

// Optionally set tab
$_GET['tab'] = 'profile';

// Capture output
ob_start();
if ( function_exists( 'sipqu_render_settings_page' ) ) {
    sipqu_render_settings_page();
} else {
    echo "Function sipqu_render_settings_page not found.\n";
}
$html = ob_get_clean();

// Save to file for inspection
file_put_contents( __DIR__ . '/settings_page_output.html', $html );

echo "Rendered settings page saved to settings_page_output.html\n";
