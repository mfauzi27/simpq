<?php
// CLI test: simulate settings form submissions (profile update + add branch)
// Usage: C:\xampp\php\php.exe tests\test_settings_form_submission.php

$WP_LOAD = 'C:/xampp/htdocs/wordpress/wp-load.php';
if ( ! file_exists( $WP_LOAD ) ) {
    echo "Cannot find wp-load.php at {$WP_LOAD}\n";
    exit(1);
}

require_once $WP_LOAD;

$plugin_main = __DIR__ . '/../sipqu-core.php';
if ( ! file_exists( $plugin_main ) ) {
    echo "Cannot find plugin main file: {$plugin_main}\n";
    exit(1);
}

require_once $plugin_main;

// Ensure roles/caps exist
if ( class_exists( 'SIPQU_Roles' ) ) {
    SIPQU_Roles::init();
}

// Set current user to user ID 1
if ( function_exists( 'wp_set_current_user' ) ) {
    wp_set_current_user( 1 );
}

// Ensure tenant context so handlers run
if ( class_exists( 'SIPQU_Tenant_Context' ) ) {
    SIPQU_Tenant_Context::set( [ 'tenant_id' => 1, 'branch_id' => 1, 'role' => 'sipqu_super_admin' ] );
}

// If admin-specific handlers not loaded (loader uses is_admin()), require file directly
if ( ! function_exists( 'sipqu_handle_settings_save' ) && defined( 'SIPQU_CORE_PATH' ) ) {
    require_once SIPQU_CORE_PATH . 'admin/settings-page.php';
}

// Helper to run and show transient message
function run_and_show_message( $action_desc ) {
    $msg = get_transient( 'sipqu_settings_message' );
    echo "After {$action_desc}: ";
    if ( $msg ) {
        echo "type={$msg['type']} message={$msg['message']}\n";
        delete_transient( 'sipqu_settings_message' );
    } else {
        echo "no transient set\n";
    }
}

// --------------------
// 1) Simulate profile update
// --------------------
// Prepare POST data and valid nonce
$_POST = [];
$_POST['sipqu_save_profile'] = '1';
if ( function_exists( 'wp_create_nonce' ) ) {
    $_POST['sipqu_profile_nonce'] = wp_create_nonce( 'sipqu_profile_action' );
}
// Fill some fields
$_POST['tenant_name'] = 'CLI Test LPQ';
$_POST['address'] = 'Jalan CLI No.1';
$_POST['phone'] = '08123456789';

// Call handler
if ( function_exists( 'sipqu_handle_settings_save' ) ) {
    sipqu_handle_settings_save();
} else {
    echo "Handler sipqu_handle_settings_save not found.\n";
}

run_and_show_message( 'profile update' );

// Clear POST
$_POST = [];

// --------------------
// 2) Simulate add branch
// --------------------
$_POST['sipqu_add_branch'] = '1';
if ( function_exists( 'wp_create_nonce' ) ) {
    $_POST['sipqu_branch_nonce'] = wp_create_nonce( 'sipqu_branch_action' );
}
$_POST['branch_name'] = 'CLI Branch Test';
$_POST['address'] = 'Cabang CLI Address';
$_POST['phone'] = '0800111222';

if ( function_exists( 'sipqu_handle_settings_save' ) ) {
    sipqu_handle_settings_save();
}

run_and_show_message( 'add branch' );

echo "Test finished.\n";

