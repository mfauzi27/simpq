<?php
/**
 * migrate_drop_recreate.php
 *
 * Destructive migration helper for local/dev only.
 * Drops SIPQU core tables and re-runs the installer to recreate them.
 * REQUIRE: run with PHP CLI and pass `--confirm` to execute destructive actions.
 *
 * Usage (PowerShell):
 *   C:\xampp\php\php.exe migrate_drop_recreate.php -- --confirm
 */

// Try common WP locations relative to plugin dir
$wp_paths = array(
    __DIR__ . '/../../../../wp-load.php',            // typical
    __DIR__ . '/../../../wp-load.php',               // alternative
    __DIR__ . '/../../wp-load.php',                  // alternative
    'C:/xampp/htdocs/wordpress/wp-load.php',          // explicit XAMPP path
);
$WP_LOAD = null;
foreach ( $wp_paths as $p ) {
    if ( file_exists( $p ) ) {
        $WP_LOAD = $p;
        break;
    }
}
if ( ! $WP_LOAD ) {
    echo "Cannot find wp-load.php in common locations. Checked:\n";
    foreach ( $wp_paths as $p ) { echo " - {$p}\n"; }
    exit(1);
}
if ( ! file_exists( $WP_LOAD ) ) {
    echo "Cannot find wp-load.php at {$WP_LOAD}\n";
    exit(1);
}

require_once $WP_LOAD;

// Load plugin main to ensure installer class is available
$plugin_main = __DIR__ . '/sipqu-core.php';
if ( ! file_exists( $plugin_main ) ) {
    echo "Cannot find plugin main file: {$plugin_main}\n";
    exit(1);
}
require_once $plugin_main;

global $wpdb, $argc, $argv;

// Safety: require explicit --confirm flag
$confirmed = false;
foreach ( $argv as $arg ) {
    if ( $arg === '--confirm' || $arg === '-y' ) {
        $confirmed = true;
        break;
    }
}

if ( ! $confirmed ) {
    echo "WARNING: This script will DROP SIPQU tables.\n";
    echo "To proceed, run: C:\\xampp\\php\\php.exe migrate_drop_recreate.php -- --confirm\n";
    exit(0);
}

$tables = array( 'tenants', 'branches', 'user_tenants', 'audit_logs' );
$prefix = $wpdb->prefix . 'sipqu_';

echo "Starting destructive migration: dropping tables:\n";
foreach ( $tables as $t ) {
    $name = $prefix . $t;
    $sql = "DROP TABLE IF EXISTS `{$name}`";
    $res = $wpdb->query( $sql );
    if ( $res === false ) {
        echo "Failed to drop {$name}: " . $wpdb->last_error . "\n";
    } else {
        echo "Dropped: {$name}\n";
    }
}

// Recreate tables via installer
if ( class_exists( 'SIPQU_Installer' ) ) {
    try {
        SIPQU_Installer::install();
        echo "Recreated SIPQU tables via SIPQU_Installer::install().\n";
    } catch ( Exception $e ) {
        echo "Installer threw exception: " . $e->getMessage() . "\n";
    }
} else {
    echo "Installer class not found. Ensure plugin files are present.\n";
}

echo "Destructive migration finished.\n";
