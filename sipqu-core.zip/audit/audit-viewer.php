<?php
/**
 * Audit Viewer UI
 *
 * Halaman Admin untuk melihat riwayat Audit Logs secara visual.
 * Menggunakan AJAX (Fetch API) untuk mengambil data dari Audit Controller.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

// ============================================================
// 1. REGISTER MENU
// ============================================================

add_action('admin_menu', 'sipqu_register_audit_viewer_menu');

function sipqu_register_audit_viewer_menu() {
    // Cek apakah user memiliki izin melihat audit
    if ( ! current_user_can( 'manage_sipqu' ) ) {
        return;
    }

    add_submenu_page(
        'sipqu',                     // Parent slug
        'Audit Logs',                // Page Title
        'Audit Logs',                // Menu Title
        'manage_sipqu',              // Capability (Custom)
        'sipqu-audit-logs',          // Menu Slug
        'sipqu_render_audit_page'     // Callback
    );
}

// ============================================================
// 2. RENDER UI
// ============================================================

function sipqu_render_audit_page() {
    ?>
    <div class="wrap">
        <h1>Riwayat Audit Sistem</h1>
        
        <div class="card" style="margin-top: 20px;">
            
            <!-- FILTERS -->
            <h2 class="title">Filter Pencarian</h2>
            <p class="description">Cari aktivitas berdasarkan modul atau tindakan.</p>
            
            <div class="tablenav top" style="margin-bottom: 15px;">
                <div class="alignleft actions">
                    <select id="audit-filter-module" class="regular-text">
                        <option value="">Semua Modul</option>
                        <option value="sws">SWS (Keuangan Santri)</option>
                        <option value="finance">Finance (Akuntansi)</option>
                        <option value="student">Student (Akademik)</option>
                        <option value="system">System</option>
                    </select>

                    <select id="audit-filter-action" class="regular-text">
                        <option value="">Semua Aksi</option>
                        <option value="create">Create (Tambah)</option>
                        <option value="update">Update (Ubah)</option>
                        <option value="delete">Delete (Hapus)</option>
                        <option value="login">Login</option>
                    </select>

                    <button type="button" id="btn-filter-audit" class="button action">Terapkan Filter</button>
                </div>
                <div class="tablenav-pages one-page">
                    <span class="displaying-num" id="audit-total-count">Loading...</span>
                </div>
                <br class="clear">
            </div>

            <!-- TABLE -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 5%;">ID</th>
                        <th style="width: 15%;">Waktu</th>
                        <th style="width: 10%;">User</th>
                        <th style="width: 10%;">Modul</th>
                        <th style="width: 10%;">Aksi</th>
                        <th style="width: 15%;">Objek</th>
                        <th style="width: 25%;">Ringkasan</th>
                        <th style="width: 10%;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="audit-tbody">
                    <tr><td colspan="8" style="text-align:center;">Memuat data...</td></tr>
                </tbody>
                <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Waktu</th>
                        <th>User</th>
                        <th>Modul</th>
                        <th>Aksi</th>
                        <th>Objek</th>
                        <th>Ringkasan</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
            </table>

            <!-- PAGINATION -->
            <div class="tablenav bottom" style="margin-top: 15px;">
                <button type="button" id="btn-load-more" class="button" style="display:none;">Muat Lebih Banyak</button>
            </div>

        </div>
    </div>

    <!-- MODAL DETAIL (Hidden by default) -->
    <div id="audit-modal" style="display:none; background: rgba(0,0,0,0.5); position:fixed; top:0; left:0; width:100%; height:100%; z-index:9999;">
        <div style="background:white; margin:50px auto; max-width:800px; padding:20px; position:relative; height:80%; overflow-y:auto;">
            <button type="button" onclick="document.getElementById('audit-modal').style.display='none'" class="button" style="position:absolute; right:20px; top:20px;">Tutup</button>
            <h2 id="modal-title">Detail Log</h2>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <h3>Old Data (Sebelum)</h3>
                    <pre id="modal-old-data" style="background:#f0f0f1; padding:10px; max-height:300px; overflow:scroll; font-size:12px;">-</pre>
                </div>
                <div>
                    <h3>New Data (Sesudah)</h3>
                    <pre id="modal-new-data" style="background:#f0f0f1; padding:10px; max-height:300px; overflow:scroll; font-size:12px;">-</pre>
                </div>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT LOGIC -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            let currentPage = 1;
            let isLoading = false;

            // Function: Fetch Audit Logs from API
            function loadAuditLogs(append = false) {
                if (isLoading) return;
                isLoading = true;

                if (!append) {
                    currentPage = 1; // Reset page jika filter baru
                    document.getElementById('audit-tbody').innerHTML = '<tr><td colspan="8" style="text-align:center;">Memuat data...</td></tr>';
                }

                const module = document.getElementById('audit-filter-module').value;
                const action = document.getElementById('audit-filter-action').value;
                const limit = 20;

                // Build URL
                let apiUrl = '/wp-json/sipqu/v1/audit/logs?page=' + currentPage + '&limit=' + limit;
                if (module) apiUrl += '&module=' + module;
                if (action) apiUrl += '&action=' + action;

                fetch(apiUrl)
                    .then(response => response.json())
                    .then(res => {
                        isLoading = false;
                        
                        if (res.status === 'success') {
                            renderRows(res.data.logs, append);
                            
                            // Update Total
                            document.getElementById('audit-total-count').textContent = res.data.total + ' item';
                            
                            // Handle Pagination Button
                            const btnMore = document.getElementById('btn-load-more');
                            if (res.data.pages > currentPage) {
                                btnMore.style.display = 'inline-block';
                            } else {
                                btnMore.style.display = 'none';
                            }
                        } else {
                            document.getElementById('audit-tbody').innerHTML = '<tr><td colspan="8" style="text-align:center;">Error: ' + res.message + '</td></tr>';
                        }
                    })
                    .catch(err => {
                        isLoading = false;
                        console.error(err);
                        document.getElementById('audit-tbody').innerHTML = '<tr><td colspan="8" style="text-align:center;">Gagal menghubungi server.</td></tr>';
                    });
            }

            // Function: Render Table Rows (store logs in map and use data-id buttons)
            const auditLogs = {};

            function renderRows(logs, append) {
                const tbody = document.getElementById('audit-tbody');
                if (!append) tbody.innerHTML = '';

                logs.forEach(log => {
                    auditLogs[ log.id ] = log;

                    // Badge Color Logic
                    let badgeClass = 'gray';
                    if (log.action === 'create') badgeClass = 'green';
                    if (log.action === 'update') badgeClass = 'blue';
                    if (log.action === 'delete') badgeClass = 'red';
                    if (log.action === 'login') badgeClass = 'purple';

                    const row = `
                        <tr>
                            <td>${log.id}</td>
                            <td><small>${log.created_at_format}</small></td>
                            <td>${log.user_id || 'System'}</td>
                            <td><strong>${log.module}</strong></td>
                            <td><span style="color:${badgeClass}; font-weight:bold;">${log.action}</span></td>
                            <td>ID: ${log.object_id || '-'}</td>
                            <td>${log.new_data ? getShortSummary(log.new_data) : '-'}</td>
                            <td>
                                <button type="button" class="button button-small btn-view-detail" data-log-id="${log.id}">Detail</button>
                            </td>
                        </tr>
                    `;
                    tbody.innerHTML += row;
                });

                // Attach event listener once (event delegation)
                const tbodyEl = document.getElementById('audit-tbody');
                tbodyEl.addEventListener('click', function(e) {
                    if ( e.target && e.target.classList && e.target.classList.contains('btn-view-detail') ) {
                        const id = e.target.getAttribute('data-log-id');
                        viewDetailById(id);
                    }
                });
            }

            // Helper: Get Short Summary from New Data (JSON)
            function getShortSummary(data) {
                if (!data || typeof data !== 'object') return '-';
                // Ambil field pertama yang ada
                const keys = Object.keys(data);
                if (keys.length === 0) return '-';
                const firstKey = keys[0];
                return `<strong>${firstKey}:</strong> ${data[firstKey]}`;
            }

            // View Detail by ID (lookup from auditLogs map)
            window.viewDetailById = function(id) {
                const log = auditLogs[ id ];
                if ( ! log ) return;
                document.getElementById('modal-title').textContent = 'Detail Log #' + log.id;
                try {
                    document.getElementById('modal-old-data').textContent = log.old_data ? JSON.stringify(log.old_data, null, 2) : '(Tidak ada perubahan / Insert)';
                } catch (e) {
                    document.getElementById('modal-old-data').textContent = String(log.old_data);
                }
                try {
                    document.getElementById('modal-new-data').textContent = log.new_data ? JSON.stringify(log.new_data, null, 2) : '-';
                } catch (e) {
                    document.getElementById('modal-new-data').textContent = String(log.new_data);
                }
                document.getElementById('audit-modal').style.display = 'block';
            };

            // Events
            document.getElementById('btn-filter-audit').addEventListener('click', () => loadAuditLogs(false));
            document.getElementById('btn-load-more').addEventListener('click', () => {
                currentPage++;
                loadAuditLogs(true);
            });

            // Initial Load
            loadAuditLogs();
        });
    </script>
    <?php
}