<?php
/**
 * Audit Trait
 *
 * Trait kecil yang menyediakan shortcut helper untuk mencatat audit dari
 * dalam class controller / model.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

trait SIPQU_Audit_Trait {

    public function logCreated( $module, $object_id = null, $new_data = null ) {
        if ( class_exists( 'SIPQU_Audit_Logger' ) ) {
            return SIPQU_Audit_Logger::created( $module, $object_id, $new_data );
        }
        return false;
    }

    public function logUpdated( $module, $object_id = null, $old_data = null, $new_data = null ) {
        if ( class_exists( 'SIPQU_Audit_Logger' ) ) {
            return SIPQU_Audit_Logger::updated( $module, $object_id, $old_data, $new_data );
        }
        return false;
    }

    public function logDeleted( $module, $object_id = null, $old_data = null ) {
        if ( class_exists( 'SIPQU_Audit_Logger' ) ) {
            return SIPQU_Audit_Logger::deleted( $module, $object_id, $old_data );
        }
        return false;
    }

}