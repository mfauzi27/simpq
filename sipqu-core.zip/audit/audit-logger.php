<?php
/**
 * Audit Logger
 *
 * Mencatat semua aktivitas sistem ke tabel audit_logs untuk keamanan dan akuntabilitas.
 * Mendukung pencatatan before/after data untuk melacak perubahan.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Audit_Logger {

    /**
     * Log Aktivitas Umum
     *
     * @param string $module      Nama modul (misal: 'sws', 'finance', 'student')
     * @param string $action      Aksi yang dilakukan (misal: 'create', 'update', 'delete', 'pay')
     * @param int    $object_id   ID dari record yang diubah
     * @param mixed  $old_data    Data sebelum perubahan (Array/Object). Akan di-encode ke JSON.
     * @param mixed  $new_data    Data sesudah perubahan (Array/Object). Akan di-encode ke JSON.
     * @return int|false ID Audit Log, atau false jika gagal.
     */
    public static function log( $module, $action, $object_id = null, $old_data = null, $new_data = null ) {
        global $wpdb;

        // Jangan log jika user belum login (kecuali untuk system events tertentu)
        if ( ! is_user_logged_in() && $action !== 'system' ) {
            return false;
        }

        // Siapkan Data Insert
        $log_data = array(
            'tenant_id'   => SIPQU_Tenant_Context::tenant_id(), // Bisa 0/null jika Super Admin
            'user_id'     => get_current_user_id(),
            'module'      => sanitize_text_field( $module ),
            'action'      => sanitize_text_field( $action ),
            'object_id'   => $object_id ? intval( $object_id ) : null,
            'old_data'    => self::sanitize_json( $old_data ),
            'new_data'    => self::sanitize_json( $new_data ),
            'ip_address'  => self::get_client_ip(),
            'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : 'CLI/Unknown',
            'created_at'  => current_time( 'mysql' )
        );

        // Insert ke Database
        return $wpdb->insert( 
            SIPQU_DB::table( 'audit_logs' ), 
            $log_data 
        );
    }

    // ============================================================
    // HELPER METHODS (Shortcut untuk aksi umum)
    // ============================================================

    /**
     * Catat Pembuatan Data Baru
     */
    public static function created( $module, $object_id, $new_data ) {
        return self::log( $module, 'create', $object_id, null, $new_data );
    }

    /**
     * Catat Update Data
     */
    public static function updated( $module, $object_id, $old_data, $new_data ) {
        return self::log( $module, 'update', $object_id, $old_data, $new_data );
    }

    /**
     * Catat Penghapusan Data
     */
    public static function deleted( $module, $object_id, $old_data ) {
        return self::log( $module, 'delete', $object_id, $old_data, null );
    }

    /**
     * Catat Aksi Login
     */
    public static function login() {
        return self::log( 'auth', 'login', null, null, array( 'status' => 'success' ) );
    }

    /**
     * Catat Gagal Login
     */
    public static function failed_login() {
        return self::log( 'auth', 'login_failed', null, null, array( 'status' => 'failed' ) );
    }

    /**
     * Catat Approval Transaksi (Contoh: Approve Jurnal, Gaji)
     */
    public static function approved( $module, $object_id, $notes = '' ) {
        return self::log( $module, 'approve', $object_id, array( 'notes' => $notes ), array( 'status' => 'approved' ) );
    }

    // ============================================================
    // UTILITIES
    // ============================================================

    /**
     * Sanitasi data sebelum di-encode ke JSON.
     * Menghapus field sensitif (password) dan mengubah object/array ke string JSON.
     *
     * @param mixed $data
     * @return string|null
     */
    private static function sanitize_json( $data ) {
        if ( empty( $data ) ) {
            return null;
        }
        // Jika object, konversi ke array rekursif terlebih dahulu
        if ( is_object( $data ) ) {
            $data = json_decode( json_encode( $data ), true );
        }

        // Jika array, hapus field sensitif dan encode ke JSON
        if ( is_array( $data ) ) {
            $data = self::remove_sensitive_fields( $data );
            return wp_json_encode( $data );
        }

        // Untuk scalar values, encode juga sebagai JSON string agar konsisten
        return wp_json_encode( $data );
    }

    /**
     * Hapus field sensitif dari log (Agar password tidak tersimpan di DB).
     */
    private static function remove_sensitive_fields( $data ) {
        // Jika bukan array, kembalikan apa adanya
        if ( ! is_array( $data ) ) {
            return $data;
        }

        $sensitive_keys = array( 'user_pass', 'password', 'token', 'secret_key', 'secret' );

        // Hapus key sensitif di level atas
        foreach ( $sensitive_keys as $key ) {
            if ( array_key_exists( $key, $data ) ) {
                unset( $data[ $key ] );
            }
        }

        // Recurse untuk nested arrays/objects yang sudah dikonversi ke array
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) {
                $data[ $k ] = self::remove_sensitive_fields( $v );
            }
        }

        return $data;
    }

    /**
     * Ambil IP Address Client yang andal.
     * Menangani kondisi user berada di balik proxy atau shared hosting.
     *
     * @return string
     */
    private static function get_client_ip() {
        $ip = '0.0.0.0';

        if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        // Sanitasi IP
        return sanitize_text_field( $ip );
    }
}