<?php
/**
 * Auth Controller
 *
 * Menangani logic untuk endpoint API Auth: Login, Logout, Get Me.
 * Mengintegrasikan sistem login WP dengan konteks Multi-Tenant SIPQU.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Auth_Controller {

    /**
     * Login User
     * Menerima username/password, verifikasi via WordPress, dan ambil Tenant mapping.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function login( $request ) {
        
        // 1. Ambil parameter
        $username = $request->get_param('username');
        $password = $request->get_param('password');

        if ( empty( $username ) || empty( $password ) ) {
            return new WP_Error( 'missing_credentials', 'Username dan Password wajib diisi.', array( 'status' => 400 ) );
        }

        // 2. Coba Signon via WordPress
        $creds = array(
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => true // Ingat user lama
        );

        $user = wp_signon( $creds, false );

        // 3. Jika Login Gagal
        if ( is_wp_error( $user ) ) {
            SIPQU_Audit_Logger::failed_login();
            return new WP_Error( 'login_failed', 'Username atau password salah.', array( 'status' => 401 ) );
        }

        // 4. Login Berhasil - Ambil ID User
        $user_id = $user->ID;

        // 5. Cek Mapping Tenant (User ini punya akses LPQ apa saja?)
        global $wpdb;
        $table_name = SIPQU_DB::table('user_tenants');

        $tenants = $wpdb->get_results( $wpdb->prepare(
            "SELECT ut.tenant_id, ut.branch_id, ut.role, t.tenant_name, b.branch_name 
             FROM {$table_name} ut
             LEFT JOIN {$wpdb->prefix}sipqu_tenants t ON ut.tenant_id = t.id
             LEFT JOIN {$wpdb->prefix}sipqu_branches b ON ut.branch_id = b.id
             WHERE ut.user_id = %d AND ut.status = 'active'",
            $user_id
        ) );

        // 6. Validasi Akses Tenant
        if ( empty( $tenants ) ) {
            wp_logout(); // Paksa logout karena tidak punya akses SIPQU
            return new WP_Error( 'no_access', 'User ini belum dipetakan ke LPQ (Tenant) manapun.', array( 'status' => 403 ) );
        }

        // 7. Logika Multi-Tenant Selection
        // Jika user hanya punya 1 tenant, set otomatis.
        // Jika user punya > 1 tenant, gunakan preferensi tersimpan atau ambil yang pertama (default).
        
        $active_tenant_meta = get_user_meta( $user_id, 'sipqu_active_tenant_id', true );
        $current_tenant = null;

        // Cari tenant aktif dari list yang tersedia
        foreach ( $tenants as $t ) {
            if ( $active_tenant_meta && $t->tenant_id == $active_tenant_meta ) {
                $current_tenant = $t;
                break;
            }
        }

        // Jika tidak ada preferensi atau preferensi tidak valid, ambil yang pertama
        if ( ! $current_tenant ) {
            $current_tenant = $tenants[0];
            // Simpan sebagai default pertama kali
            update_user_meta( $user_id, 'sipqu_active_tenant_id', $current_tenant->tenant_id );
            update_user_meta( $user_id, 'sipqu_active_branch_id', $current_tenant->branch_id );
        }

        // 8. Set Context ke Global (Simulasi Session)
        SIPQU_Tenant_Context::set( [
            'tenant_id' => $current_tenant->tenant_id,
            'branch_id' => $current_tenant->branch_id,
            'role'      => $current_tenant->role
        ] );

        // 9. Log Audit Success
        SIPQU_Audit_Logger::login();

        // 10. Return Response
        $response_data = array(
            'user_id'       => $user_id,
            'display_name'  => $user->display_name,
            'email'         => $user->user_email,
            'role'          => $current_tenant->role,
            'current_tenant' => array(
                'id'   => $current_tenant->tenant_id,
                'name' => $current_tenant->tenant_name,
                'branch' => $current_tenant->branch_name,
                'branch_id' => $current_tenant->branch_id
            ),
            'available_tenants' => $tenants // List semua tenant untuk dropdown switcher di Frontend
        );

        return new WP_REST_Response( array(
            'status'  => 'success',
            'message' => 'Login berhasil',
            'data'    => $response_data
        ), 200 );
    }

    /**
     * Logout User
     * Menghapus sesi dan context.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function logout( $request ) {
        
        // Log audit sebelum logout
        if ( is_user_logged_in() ) {
            SIPQU_Audit_Logger::log( 'auth', 'logout', get_current_user_id(), null, null );
        }

        // Flush Context
        SIPQU_Tenant_Context::flush();

        // Logout WP
        wp_logout();

        return new WP_REST_Response( array(
            'status'  => 'success',
            'message' => 'Logout berhasil'
        ), 200 );
    }

    /**
     * Get User Info (Me)
     * Mengambil data user aktif dan context tenant saat ini.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function me( $request ) {

        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'not_logged_in', 'Sesi kadaluarsa atau belum login.', array( 'status' => 401 ) );
        }

        $user_id = get_current_user_id();
        $user = get_userdata( $user_id );

        // Ambil Context saat ini
        $context = SIPQU_Tenant_Context::get();

        // Ambil semua tenant milik user untuk keperluan switcher
        global $wpdb;
        $table_name = SIPQU_DB::table('user_tenants');
        
        $all_tenants = $wpdb->get_results( $wpdb->prepare(
            "SELECT ut.tenant_id, t.tenant_name, ut.role 
             FROM {$table_name} ut
             JOIN {$wpdb->prefix}sipqu_tenants t ON ut.tenant_id = t.id
             WHERE ut.user_id = %d AND ut.status = 'active'",
            $user_id
        ) );

        $response_data = array(
            'id'           => $user_id,
            'name'         => $user->display_name,
            'email'        => $user->user_email,
            'avatar_url'   => get_avatar_url( $user_id, array('size' => 100) ),
            'role'         => $context['role'] ?? null,
            'current_tenant' => array(
                'id'   => $context['tenant_id'] ?? null,
                'branch_id' => $context['branch_id'] ?? null
            ),
            'all_tenants'  => $all_tenants // List opsi ganti LPQ
        );

        return new WP_REST_Response( array(
            'status' => 'success',
            'data'   => $response_data
        ), 200 );
    }
}