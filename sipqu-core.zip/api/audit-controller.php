<?php
/**
 * Audit Controller
 *
 * Menangani endpoint API untuk melihat riwayat Audit Logs.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_Audit_Controller {

    /**
     * Get Audit Logs
     * Endpoint: GET /sipqu/v1/audit/logs
     *
     * Mendapatkan daftar log dengan dukungan filter dan pagination.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function get_logs( $request ) {
        
        // 1. Validasi Permission
        // Hanya role yang memiliki capability 'audit.view' yang boleh akses.
        // Biasanya ini dibatasi untuk Super Admin atau Manager.
        if ( ! SIPQU_Capability::check( 'audit.view', false ) ) {
            return SIPQU_Response::error( 'Anda tidak memiliki izin melihat Audit Log.', 403 );
        }

        // 2. Ambil Parameter Request
        $page      = $request->get_param( 'page' ) ?: 1;
        $limit     = $request->get_param( 'limit' ) ?: 20;
        $module    = $request->get_param( 'module' );
        $action    = $request->get_param( 'action' );
        $user_id   = $request->get_param( 'user_id' );
        
        // Optional: Date Range Filter
        $date_from = $request->get_param( 'date_from' );
        $date_to   = $request->get_param( 'date_to' );

        global $wpdb;
        $table = SIPQU_DB::table( 'audit_logs' );

        // 3. Bangun Klausa WHERE
        $where_parts = array( "1=1" );
        $where_args  = array();

        // Filter A: Tenant Isolation (Security)
        // Jika user adalah Super Admin, mungkin dia ingin lihat semua log sistem.
        // Namun, secara default kita kunci ke tenant aktif demi keamanan LPQ.
        // Kecuali ada parameter `include_all=true` (opsional, tidak diimplementasikan disini).
        $tenant_id = SIPQU_Tenant_Context::tenant_id();
        
        // Khusus: Jika tenant_id 0 (System/Global) atau user Super Admin, logika bisa disesuaikan.
        // Di sini kita kunci ke tenant user agar data tidak bocor.
        if ( $tenant_id ) {
            $where_parts[] = "(tenant_id = %d OR tenant_id = 0)"; // Bisa lihat log global (0) juga
            $where_args[]  = $tenant_id;
        }

        // Filter B: Module (sws, finance, etc)
        if ( ! empty( $module ) ) {
            $where_parts[] = "module = %s";
            $where_args[]  = sanitize_text_field( $module );
        }

        // Filter C: Action (create, update, delete)
        if ( ! empty( $action ) ) {
            $where_parts[] = "action = %s";
            $where_args[]  = sanitize_text_field( $action );
        }

        // Filter D: User ID (Lihat log user spesifik)
        if ( ! empty( $user_id ) ) {
            $where_parts[] = "user_id = %d";
            $where_args[]  = intval( $user_id );
        }

        // Filter E: Date Range
        if ( ! empty( $date_from ) ) {
            $where_parts[] = "created_at >= %s";
            $where_args[]  = $date_from;
        }
        if ( ! empty( $date_to ) ) {
            $where_parts[] = "created_at <= %s";
            $where_args[]  = $date_to;
        }

        // Gabungkan WHERE
        $where_clause = implode( ' AND ', $where_parts );

        // 4. Hitung Total Data (Untuk Pagination)
        $count_sql = "SELECT COUNT(id) FROM {$table} WHERE {$where_clause}";
        $total = $wpdb->get_var( $wpdb->prepare( $count_sql, $where_args ) );

        // 5. Ambil Data
        $offset = ( $page - 1 ) * $limit;
        
        $data_sql = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY created_at DESC LIMIT %d OFFSET %d";
        
        // Gabungkan $where_args dengan $limit dan $offset
        $query_args = array_merge( $where_args, array( $limit, $offset ) );
        
        $logs = $wpdb->get_results( $wpdb->prepare( $data_sql, $query_args ) );

        // 6. Format Output (Decode JSON)
        // Kolom old_data dan new_data tersimpan sebagai string JSON di DB.
        // Kita decode ke array/object agar frontend mudah membacanya.
        foreach ( $logs as &$log ) {
            $log->old_data = json_decode( $log->old_data );
            $log->new_data = json_decode( $log->new_data );
            // Format tanggal agar cantik
            $log->created_at_format = SIPQU_Formatter::datetime( $log->created_at );
        }

        // 7. Return Response
        return SIPQU_Response::success( array(
            'logs'  => $logs,
            'total' => intval( $total ),
            'pages' => ceil( $total / $limit )
        ), 'Audit logs retrieved successfully.', 200 );
    }

    /**
     * Get Detail Log (Optional Single Item)
     * Endpoint: GET /sipqu/v1/audit/logs/{id}
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function get_log_detail( $request ) {
        
        if ( ! SIPQU_Capability::check( 'audit.view', false ) ) {
            return SIPQU_Response::error( 'Akses ditolak.', 403 );
        }

        $log_id = $request->get_param( 'id' );
        global $wpdb;
        $table = SIPQU_DB::table( 'audit_logs' );

        $log = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d", 
            $log_id
        ) );

        if ( ! $log ) {
            return SIPQU_Response::error( 'Log tidak ditemukan.', 404 );
        }

        // Cek Permission Tenant (Admin LPQ A tidak boleh lihat log LPQ B)
        $tenant_id = SIPQU_Tenant_Context::tenant_id();
        if ( $tenant_id && $log->tenant_id != $tenant_id && $log->tenant_id != 0 ) {
            return SIPQU_Response::error( 'Anda tidak berhak melihat log ini.', 403 );
        }

        // Decode Data
        $log->old_data = json_decode( $log->old_data );
        $log->new_data = json_decode( $log->new_data );

        return SIPQU_Response::success( $log, 'Log detail retrieved.', 200 );
    }
}