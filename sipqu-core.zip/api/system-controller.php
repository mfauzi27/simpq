<?php
/**
 * System Controller
 *
 * Menangani endpoint sistem: Health Check dan Configuration Settings.
 * Mengambil pengaturan global dan pengaturan spesifik Tenant.
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_System_Controller {

    /**
     * Health Check
     * Memeriksa koneksi database dan versi sistem.
     * Endpoint ini biasanya dipakai Load Balancer atau Monitor.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function health( $request ) {
        global $wpdb;

        // 1. Cek Koneksi Database
        // Coba query sederhana untuk memastikan DB hidup
        $db_alive = $wpdb->get_var( "SELECT 1" ) === '1';

        if ( ! $db_alive ) {
            return new WP_Error( 'db_error', 'Koneksi database gagal.', array( 'status' => 503 ) );
        }

        // 2. Cek Versi Plugin
        $plugin_version = defined( 'SIPQU_CORE_VERSION' ) ? SIPQU_CORE_VERSION : 'unknown';
        
        // 3. Cek Status Upgrade Database
        $current_db_version = get_option( 'sipqu_db_version', '0' );
        $target_db_version  = defined( 'SIPQU_DB_VERSION' ) ? SIPQU_DB_VERSION : '0';
        $db_up_to_date     = version_compare( $current_db_version, $target_db_version, '>=' );

        // 4. Response
        return new WP_REST_Response( array(
            'status'  => 'ok',
            'message' => 'Sistem berjalan normal',
            'data'    => array(
                'timestamp'          => current_time( 'mysql' ),
                'plugin_version'      => $plugin_version,
                'db_version'         => $current_db_version,
                'db_up_to_date'      => $db_up_to_date,
                'php_version'        => PHP_VERSION,
                'wp_version'         => get_bloginfo( 'version' ),
                'server_time'        => date_i18n( 'Y-m-d H:i:s' )
            )
        ), 200 );
    }

    /**
     * Get System Settings
     * Mengambil konfigurasi sistem global + setting khusus Tenant aktif.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function settings( $request ) {
        
        // 1. Pastikan user login
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'unauthorized', 'Anda harus login.', array( 'status' => 401 ) );
        }

        // 2. Pastikan Tenant Context siap
        $tenant_id = SIPQU_Tenant_Context::tenant_id();
        if ( empty( $tenant_id ) ) {
            return new WP_Error( 'no_context', 'Konteks Tenant tidak ditemukan.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'sipqu_';

        // 3. Ambil Data Tenant (Nama LPQ, dll)
        $tenant = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, tenant_name, settings, subscription_plan 
             FROM {$prefix}tenants 
             WHERE id = %d",
            $tenant_id
        ) );

        if ( ! $tenant ) {
            return new WP_Error( 'tenant_not_found', 'Data LPQ tidak ditemukan.', array( 'status' => 404 ) );
        }

        // 4. Decode JSON Settings dari Database
        // Kolom 'settings' di tabel tenants berisi config spesifik (misal: email admin, logo, dll)
        $tenant_settings = json_decode( $tenant->settings, true );
        if ( ! is_array( $tenant_settings ) ) {
            $tenant_settings = array();
        }

        // 5. Tentukan Default App Config
        // Ini adalah config standar aplikasi Frontend
        $app_defaults = array(
            'currency'           => 'IDR', // Rupiah
            'currency_symbol'    => 'Rp',
            'date_format'        => 'd/m/Y',
            'time_format'        => 'H:i',
            'decimal_separator' => ',',
            'thousand_separator' => '.',
            'app_name'           => get_bloginfo( 'name' ),
            'locale'             => get_locale()
        );

        // 6. Merge Config (Tenant Settings override Defaults jika ada)
        $final_settings = array_merge( $app_defaults, $tenant_settings );

        // 7. Return Data
        return new WP_REST_Response( array(
            'status' => 'success',
            'data'   => array(
                'tenant' => array(
                    'id'                => $tenant->id,
                    'name'              => $tenant->tenant_name,
                    'subscription_plan' => $tenant->subscription_plan,
                ),
                'config' => $final_settings
            )
        ), 200 );
    }
}