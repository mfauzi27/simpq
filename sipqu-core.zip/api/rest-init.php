<?php
/**
 * REST API Init - Route Dispatcher
 *
 * Mendaftarkan semua endpoint REST API SIPQU.
 * Namespace: /wp-json/sipqu/v1/
 *
 * @package SIPQU_CORE
 */

defined('ABSPATH') || exit;

class SIPQU_REST_Init {

    /**
     * Mendaftarkan semua rute API.
     * Dipanggil via hook 'rest_api_init' di loader.php.
     *
     * @return void
     */
    public static function register_routes() {

        // ============================================================
        // 1. AUTHENTICATION ROUTES
        // Endpoint ini dapat diakses publik (tanpa login WP Session) untuk Login API
        // ============================================================
        
        // POST /wp-json/sipqu/v1/auth/login
        // Deskripsi: Login untuk mendapatkan Session/User Context.
        register_rest_route( 'sipqu/v1', '/auth/login', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( 'SIPQU_Auth_Controller', 'login' ),
            'permission_callback' => '__return_true', // Publik
        ) );

        // POST /wp-json/sipqu/v1/auth/logout
        // Deskripsi: Logout sesi user.
        register_rest_route( 'sipqu/v1', '/auth/logout', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( 'SIPQU_Auth_Controller', 'logout' ),
            'permission_callback' => function() {
                return is_user_logged_in();
            }
        ) );

        // GET /wp-json/sipqu/v1/auth/me
        // Deskripsi: Mendapatkan profil user aktif & tenant context saat ini.
        register_rest_route( 'sipqu/v1', '/auth/me', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( 'SIPQU_Auth_Controller', 'me' ),
            'permission_callback' => function() {
                return is_user_logged_in();
            }
        ) );

        // ============================================================
        // 2. SYSTEM ROUTES
        // Endpoint untuk pengecekan kesehatan dan konfigurasi sistem
        // ============================================================

        // GET /wp-json/sipqu/v1/system/health
        // Deskripsi: Cek status sistem dan koneksi database.
        register_rest_route( 'sipqu/v1', '/system/health', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( 'SIPQU_System_Controller', 'health' ),
            'permission_callback' => '__return_true', // Public (untuk monitoring)
        ) );

        // GET /wp-json/sipqu/v1/system/settings
        // Deskripsi: Mendapatkan konfigurasi sistem (JSON settings tenant).
        register_rest_route( 'sipqu/v1', '/system/settings', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( 'SIPQU_System_Controller', 'settings' ),
            'permission_callback' => function() {
                return is_user_logged_in();
            }
        ) );

        // ============================================================
        // 3. AUDIT & LOG ROUTES (Contoh Lain)
        // ============================================================

        // GET /wp-json/sipqu/v1/audit/logs
        // Deskripsi: Mengambil history audit trail.
        register_rest_route( 'sipqu/v1', '/audit/logs', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( 'SIPQU_Audit_Controller', 'get_logs' ),
            'permission_callback' => function() {
                // Hanya role admin atau super admin yang bisa lihat audit log
                return SIPQU_Capability::check( 'audit.view', false ); 
            },
            'args'                => array(
                'limit' => array(
                    'validate_callback' => function($param) { return is_numeric($param); }
                ),
                'page'  => array(
                    'validate_callback' => function($param) { return is_numeric($param); }
                )
            )
        ) );

        // ============================================================
        // CATATAN: Route untuk Modul Lain (SWS, Finance, dll)
        // ============================================================
        // Route untuk modul lain (misal /sws/invoices) sebaiknya 
        // didaftarkan di file masing-masing modul (sipqu-sws/api.php)
        // agar tetap modular. Namun mereka wajib menggunakan namespace 'sipqu/v1'.
        
    }

    // ============================================================
    // SHARED MIDDLEWARE / HELPER
    // ============================================================

    /**
     * Helper untuk memvalidasi bahwa request memiliki Tenant Context yang valid.
     * Digunakan di permission_callback route yang memerlukan tenant_id.
     */
    public static function is_tenant_ready() {
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'no_auth', 'Silakan login terlebih dahulu.', array( 'status' => 401 ) );
        }

        // Cek apakah tenant context berhasil di-resolve
        if ( empty( SIPQU_Tenant_Context::tenant_id() ) ) {
            return new WP_Error( 'no_context', 'User ini belum dipetakan ke LPQ (Tenant) manapun.', array( 'status' => 403 ) );
        }

        return true;
    }
}