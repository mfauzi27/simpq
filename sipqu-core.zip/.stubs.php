<?php

// WordPress Core Stubs for IDE Linter
// This file is never loaded, it just helps the IDE understand WordPress functions.

if (!defined('ABSPATH')) {
    define('ABSPATH', '/');
}

function add_action($tag, $function_to_add, $priority = 10, $accepted_args = 1) {}
function add_filter($tag, $function_to_add, $priority = 10, $accepted_args = 1) {}
function register_activation_hook($file, $function) {}
function register_deactivation_hook($file, $function) {}
function plugin_dir_url($file) { return ''; }
function plugins_url($path = '', $plugin = '') { return ''; }
function plugin_basename($file) { return ''; }
function load_plugin_textdomain($domain, $deprecated = false, $plugin_rel_path = false) {}
function is_admin() { return false; }
function is_user_logged_in() { return false; }
function wp_enqueue_style($handle, $src = '', $deps = array(), $ver = false, $media = 'all') {}
function wp_enqueue_script($handle, $src = '', $deps = array(), $ver = false, $in_footer = false) {}
function wp_localize_script($handle, $object_name, $l10n) {}
function rest_url($path = '', $scheme = 'rest') { return ''; }
function wp_create_nonce($action = -1) { return ''; }
function esc_html__($text, $domain = 'default') { return $text; }
function wp_kses_post($data) { return $data; }
function update_option($option, $value, $autoload = null) {}
function get_option($option, $default = false) { return $default; }
function dbDelta($sql) {}
function trailingslashit($string) { return $string; }

class wpdb {
    public $prefix = 'wp_';
    public function get_charset_collate() { return ''; }
    public function prepare($query, $args) { return $query; }
    public function get_row($query, $output = OBJECT, $y = 0) {}
    public function query($query) {}
}

class WP_REST_Server {
    const READABLE = 'GET';
    const CREATABLE = 'POST';
    const EDITABLE = 'PUT, PATCH';
    const DELETABLE = 'DELETE';
    const ALLMETHODS = 'GET, POST, PUT, PATCH, DELETE';
}

function register_rest_route($namespace, $route, $args = array(), $override = false) {}
