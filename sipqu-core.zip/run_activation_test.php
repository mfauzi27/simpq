<?php
// Simple CLI test to run plugin activation and deactivation.
// Usage: C:\xampp\php\php.exe run_activation_test.php

$WP_LOAD = 'C:/xampp/htdocs/wordpress/wp-load.php';
if ( ! file_exists( $WP_LOAD ) ) {
    echo "Cannot find wp-load.php at {$WP_LOAD}\n";
    exit(1);
}

require_once $WP_LOAD;

$plugin_main = __DIR__ . '/sipqu-core.php';
if ( ! file_exists( $plugin_main ) ) {
    echo "Cannot find plugin main file: {$plugin_main}\n";
    exit(1);
}

require_once $plugin_main;

try {
    echo "Calling SIPQU_Core_Activator::activate()...\n";
    if ( class_exists( 'SIPQU_Core_Activator' ) ) {
        SIPQU_Core_Activator::activate();
        echo "Activation completed.\n";
    } else {
        echo "Activator class not found.\n";
    }

    // Show if option was set
    $activated = get_option( 'sipqu_activated' );
    echo "Option sipqu_activated = ";
    var_export( $activated );
    echo "\n";

    // List scheduled hooks related to sipqu
    global $wpdb;
    $cron = _get_cron_array();
    $found = false;
    foreach ( $cron as $timestamp => $hooks ) {
        foreach ( $hooks as $hook => $args ) {
            if ( strpos( $hook, 'sipqu_' ) !== false ) {
                echo "Scheduled: {$hook} at {$timestamp}\n";
                $found = true;
            }
        }
    }
    if ( ! $found ) {
        echo "No sipqu scheduled hooks found.\n";
    }

    echo "Calling SIPQU_Core_Deactivator::deactivate()...\n";
    if ( class_exists( 'SIPQU_Core_Deactivator' ) ) {
        SIPQU_Core_Deactivator::deactivate();
        echo "Deactivation completed.\n";
    } else {
        echo "Deactivator class not found.\n";
    }

    $activated_after = get_option( 'sipqu_activated' );
    echo "Option sipqu_activated after deactivate = ";
    var_export( $activated_after );
    echo "\n";

} catch ( Exception $e ) {
    echo "Exception: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString();
}

echo "Test finished.\n";
